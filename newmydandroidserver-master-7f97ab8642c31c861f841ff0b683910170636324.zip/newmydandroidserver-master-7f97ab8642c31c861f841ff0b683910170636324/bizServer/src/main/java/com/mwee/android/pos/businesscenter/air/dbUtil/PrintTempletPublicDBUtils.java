package com.mwee.android.pos.businesscenter.air.dbUtil;

import com.alibaba.fastjson.JSONObject;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.myd.server.dbmodel.print.PrintTempletPublicDBModel;

/**
 * Created by qinwei on 2018/8/29.
 */

public class PrintTempletPublicDBUtils {

    public static PrintTempletPublicDBModel queryById(String id) {
        String sql = "select * from tbPrintTempletPublic where fsTempletId='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrintTempletPublicDBModel.class);
    }

    public static PrintTempletPublicDBModel queryUsedTempletByTempletKey(String fsTempletKey) {
        String templetId = TicketTempletUtils.findDefultTempletId(fsTempletKey);
        return null;
    }

    /**
     * 根据模版id查询模版数据
     *
     * @param fsTempletId
     * @return
     */
    public static JSONObject queryTempleDataById(String fsTempletId) {
        String sql = "select fsTempletData from tbPrintTempletPublic where fsTempletId='" + fsTempletId + "'";
        return JSONObject.parseObject(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql));
    }
}
