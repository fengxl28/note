package com.mwee.android.pos.businesscenter.business.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayBean;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.business.rapid.api.bean.model.NetOrderType;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidOrder;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayment;
import com.mwee.android.pos.business.rapid.api.bean.model.SourceType;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.message.MessageAbnormalOrderBizProcessor;
import com.mwee.android.pos.businesscenter.business.message.MessageOrderUtil;
import com.mwee.android.pos.businesscenter.business.pay.PayUtil;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidApi;
import com.mwee.android.pos.businesscenter.business.rapid.processor.RapidBiz;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.netbiz.member.MemberInfo;
import com.mwee.android.pos.businesscenter.print.PrintBillUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.pay.PayResultResponse;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.ServerSettingHelper;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.message.MessageConstance;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.jsonfilter.RapidJsonFilter;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;

/**
 * Created by liuxiuxiu on 2018/10/24.
 */

public class KBAfterPayProcessor {

    /**
     * 口碑后付款支付通知
     */
    public static synchronized void afterPayNotify(RapidActionModel resultData, RapidGetModel data) {

        if (!(APPConfig.isAirKouBei() || APPConfig.isMydKouBei())) {
            RapidBiz.buildResultError(resultData, "当前门店不是口碑模式!");
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送口碑后付 当前模式不是口碑店铺 不做处理--> 推送 口碑后付 付款信息 ： ", JSON.toJSONString(data));
            return;
        }

        try {
//            JSONObject object = JSONObject.parseObject(data.fstdata);
            KBAfterPayBean kbAfterPayBean = JSON.parseObject(data.fstdata, KBAfterPayBean.class);
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "推送口碑后付 付款信息", JSON.toJSONString(kbAfterPayBean));
            buildPayment(resultData, kbAfterPayBean.out_biz_no, kbAfterPayBean);
        } catch (Exception e) {
            LogUtil.logError("推送口碑后付 处理异常 " + JSON.toJSONString(data), e);
            RapidBiz.buildResultError(resultData, "口碑后付处理异常!");
            return;
        }
    }

    /**
     * 构建支付信息
     *
     * @param resultData
     * @param kbAfterPayBean
     */
    public synchronized static void buildPayment(RapidActionModel resultData, String localOrderId, KBAfterPayBean kbAfterPayBean) {

        if (kbAfterPayBean == null) {
            RapidBiz.buildResultError(resultData, "无法识别口碑支付信息!");
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 支付信息为null", "", "", resultData.fsid, kbAfterPayBean);
            return;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(localOrderId);

        if (orderCache == null) {
            RapidBiz.buildResultError(resultData, "未查到订单信息!");
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 支付失败, 未查询到订单信息", localOrderId, "", resultData.fsid, kbAfterPayBean);
            //TODO 入异常订单
            MessageAbnormalOrderBizProcessor.addKBAfterPayAbnormalMsg(kbAfterPayBean, "未查到订单号为：[" + localOrderId + "]的订单信息");
            return;
        }

        //检查反结账---纯收银不校验是否正在反结账
        if (OrderStatus.ANTI_PAIED == orderCache.orderStatus) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 桌台[" + orderCache.fsmtableid + "]正在反结账 (buildPayment)",
                    resultData.fsid, orderCache.fsmtableid);
        }

        UserDBModel userCash = RapidBiz.getCloudUser();
        if (userCash == null) {
            RapidBiz.buildResultError(resultData, "未查询到云收银账号");
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 未找到云收银[fsStaffId = 'cash']的账号", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, orderCache.fsmtableid);
            //TODO 入异常订单
            MessageAbnormalOrderBizProcessor.addKBAfterPayAbnormalMsg(kbAfterPayBean, "未查询到云收银账号");
            return;
        }

        PaySession originSession;
        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(orderCache.fsmtableid, orderCache.orderID, "收到口碑后付付款信息，构建支付信息");
        try {
            orderCache = OrderSession.getInstance().getOrder(orderCache.orderID);
            originSession = OrderSession.getInstance().getPay(orderCache.orderID);
            if (originSession == null) {
                originSession = OrderSession.getInstance().generatePaySession(orderCache, userCash, HostBiz.cloudsite);
            }

            //如果订单已完成结账，则不再接受支付信息
            if (originSession != null && 1 == originSession.payed && orderCache.orderStatus == OrderStatus.PAIED) {
                RapidBiz.buildResultError(resultData, "该笔订单已支付!");
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 订单支付失败,该笔订单已支付", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                //TODO 入异常订单
                MessageAbnormalOrderBizProcessor.addKBAfterPayAbnormalMsg(kbAfterPayBean, orderCache.orderID + "订单已结账");
                return;
            }

            //根据结账时间，处理重复推送,重复推送可以反馈为已处理
            if (originSession != null && 1 == originSession.payed && TextUtils.equals(originSession.payTime, kbAfterPayBean.pay_time)) {
                RapidBiz.buildResultError(resultData, "该笔支付已处理!");
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑后付 该笔订单已支付", orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                return;
            }

            String orderToken = ServerCache.getInstance().generateNewToken(orderCache.orderID);


            StringBuilder sb = new StringBuilder();
            if (orderCache.thirdOrderId.length() > 0) {
                if (!orderCache.thirdOrderId.contains(kbAfterPayBean.order_id)) {
                    sb.append(kbAfterPayBean.order_id).append(",");
                }
            } else {
                sb.append(kbAfterPayBean.order_id).append(",");
            }
            sb.append(orderCache.thirdOrderId);
            // TODO: 2018/11/7 秀秀说把最后,去掉
            if (sb.toString().endsWith(",")) {
                orderCache.thirdOrderId = sb.substring(0, sb.length() - 1);
            } else {
                orderCache.thirdOrderId = sb.toString();
            }


            //刷新订单的满减的相关的待支付
            OrderUtil.recalcCouponCutWithPay(originSession, orderCache, false);
            //构建支付信息
            RapidPayment rapidPayment = new RapidPayment();
            rapidPayment.orderId = kbAfterPayBean.order_id;
            rapidPayment.bizType = NetOrderType.KB_AFTER_PAY;
            rapidPayment.paymentList.addAll(kbAfterPayBean.rapidPayModels);
            PayModel parentPay = RapidBiz.buildRapidPayModel(orderCache, rapidPayment, resultData);
            if (parentPay == null) {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑付款明细落帐失败:构建支付信息失败  " + resultData.errorInfo, orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                RapidBiz.buildResultError(resultData, TextUtils.isEmpty(resultData.errorInfo) ? "口碑付款明细落帐失败:" : resultData.errorInfo);
                //TODO 入异常订单
                MessageAbnormalOrderBizProcessor.addKBAfterPayAbnormalMsg(kbAfterPayBean, "口碑付款明细落帐失败:" + resultData.errorInfo);
                return;
            } else {
                parentPay.decreasRapid();
                parentPay.thirdPaymentId = kbAfterPayBean.payment_id;
                if (!ListUtil.isEmpty(parentPay.secondPayList)) {
                    for (PayModel model : parentPay.secondPayList) {
                        if (model != null) {
                            model.decreasRapid();
                            model.thirdPaymentId = kbAfterPayBean.payment_id;
                        }
                    }
                }
            }

            //将支付明细进行落帐
            SocketResponse<PayResultResponse> socketResponse = BillUtil.addPayDetail(orderToken, orderCache.orderID, userCash, HostBiz.cloudsite, true, parentPay);
            if (socketResponse.success()) {
                OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, false, "KBAfterPayProcessor buildPayment");
                if (socketResponse.success()
//                        && TextUtils.isEmpty(orderCache.checkToPay()) ) {
                        && TextUtils.isEmpty(orderCache.checkToPay())
                        && ((PayUtil.supportAutoPay(orderCache.fiSellType) && !NetOrderType.isRapidPrePay(rapidPayment.bizType)) || (orderCache.dinnerModel() && PayUtil.supportPreRapidAutoPay() && NetOrderType.isRapidPrePay(rapidPayment.bizType)))
                        ) {
                    RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑付款明细调动成功:" + socketResponse.message, orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                    SocketResponse<PayResultResponse> socketAutoResponse = BillUtil.checkAutoFinishAndStart(orderToken, orderCache.orderID, true, null, userCash, HostBiz.cloudsite, false);
                    socketResponse.data = socketAutoResponse.data;
                    if (socketAutoResponse.success()) {
                        PrintBillUtil.printRapidDinnerBill(orderCache, null, userCash);
                    }
                }
            } else {
                RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑付款明细落帐失败:" + socketResponse.message, orderCache.orderID, orderCache.fsmtableid, resultData.fsid, originSession);
                RapidBiz.buildResultError(resultData, "口碑付款明细落帐失败:" + socketResponse.message);
                //TODO 入异常订单
                MessageAbnormalOrderBizProcessor.addKBAfterPayAbnormalMsg(kbAfterPayBean, "口碑付款明细落帐失败:" + socketResponse.message);
                return;
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, orderCache.fsmtableid, orderCache.orderID, "收到口碑后付付款信息，构建支付信息");
        }
        NotifyToClient.kbFutureOrderPay(orderCache.fsmtableid, orderCache.fsmtablename);

        //todo 扫码接单需要退出桌台（解决秒点扫码接单桌台没锁住bug）
        NotifyToClient.refreshkborderchange(orderCache.fsmtableid, orderCache.fsmtablename);
    }


}
