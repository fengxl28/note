package com.mwee.android.pos.businesscenter.business.order;

import android.support.v4.util.ArrayMap;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.pos.base.BizConstant;
import com.mwee.android.pos.business.constants.CouponType;
import com.mwee.android.pos.business.member.entity.MemberConfig;
import com.mwee.android.pos.businesscenter.business.kds.KdsManager;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.discount.DiscountMenuItem;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.DiscountDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.config.DBOrderConfig;
import com.mwee.android.pos.db.business.menu.DiscountType;
import com.mwee.android.pos.db.business.menu.MenuItemVipPriceUtil;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.order.discount.BuyGiftItemModel;
import com.mwee.android.pos.db.business.order.discount.CouponBuyGiftModel;
import com.mwee.android.pos.db.business.order.discount.CouponUtil;
import com.mwee.android.pos.db.business.order.discount.DiscountBizModel;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by liuxiuxiu on 2017/9/19.
 */

public class DiscountBizUtil {

    private static final String TAG = "DiscountBizUtil";

    public static List<DiscountMenuItem> menuItem2DiscountMenuItem(List<MenuItem> menuItemList) {
        List<DiscountMenuItem> discountMenuItemList = new ArrayList<>();
        if (!ListUtil.isEmpty(menuItemList)) {
            for (MenuItem menuItem : menuItemList) {
                discountMenuItemList.add(new DiscountMenuItem(menuItem.menuBiz.uniq, menuItem.itemID, menuItem.currentUnit.fiOrderUintCd, menuItem.config, menuItem.categoryCode));
            }
        }
        return discountMenuItemList;
    }

    /**
     * 查询每个菜品对应的折扣ID列表
     *
     * @param discountMenuItemList 菜品数据集合
     * @retrun key: 菜品uniq_菜品规格ID   value: List<折扣ID>
     */
    public static ArrayMap<String, List<String>> getAllMenuItemAndDiscountIDs(List<DiscountMenuItem> discountMenuItemList) {
        ArrayMap<String, List<String>> menuItemAndDiscountMap = new ArrayMap<>();
        menuItemAndDiscountMap.clear();
        for (DiscountMenuItem menuItem : discountMenuItemList) {
            String key = menuItem.uniq + "_" + menuItem.fiItemUnitCd;
            List<String> discountIDList = menuItemAndDiscountMap.get(key);
            if (ListUtil.isEmpty(discountIDList)) {
                String sql = "select * from (select fsdiscountid from tbDiscountItem where fiItemCd = '" + menuItem.fiItemCd + "' and fiOrderUintCd = '" + menuItem.fiItemUnitCd + "' and fiStatus = '1'" +
                        "union all " +
                        "select fsdiscountid from tbdiscountmenucls where fsMenuClsId = '" + menuItem.categoryCode + "' and fistatus = '1')";

//                String sql = "select fsDiscountId from tbDiscountItem where fiItemCd = '" + menuItem.fiItemCd + "' and fiOrderUintCd = '" + menuItem.fiItemUnitCd + "' and fiStatus = '1'";
                discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
//                if (ListUtil.isEmpty(discountIDList)) {
//                    String discountMenuClsSQL = "select fsDiscountId from tbdiscountmenucls where fsMenuClsId = '" + menuItem.categoryCode + "'  and fiStatus = '1'";
//                    discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, discountMenuClsSQL);
//                }
                if (ListUtil.isEmpty(discountIDList)) {
                    discountIDList = new ArrayList<>();
                }
                menuItemAndDiscountMap.put(key, discountIDList);
            }
        }
        return menuItemAndDiscountMap;
    }

    /**
     * 全部折扣方案列表,不包含整单立减、现金折
     * 整单折扣、部分菜品折扣
     *
     */
    public static List<DiscountDBModel> optDiscountList(String fsShopGUID, String csId) {
        String sql = "select tbdiscount.fsDiscountId,tbdiscount.fsDiscountName, tbdiscount.ficouponid, tbdiscount.fiDiscReason,tbdiscount.fiIsEffectiveDate," +
        "tbdiscount.fsStarDate,tbdiscount.fsEndDate,tbdiscount.fsCompanyId,tbdiscount.fiIsDisMenu, " +
        "tbdiscount.fdddv,tbdiscount.fiDiscountRate, tbDiscount.fiIsVIPUse, " +
        " discountVip.fiviplevelId fiVIPId from tbdiscount " +
        " left join (select * from tbdiscountvip where fivipCardCsId = '"+csId+"' and fistatus = '1' ) discountVip " +
        "on discountVip.fsDiscountId = tbdiscount.fsDiscountId " +
        "where tbdiscount.fiStatus='1' and tbdiscount.fsShopGUID='" + fsShopGUID + "' " +
        "and tbdiscount.ficouponid <> '1' and tbdiscount.fsDiscountId!='" + DiscountType.CASH + "' " +
        "and tbdiscount.fsDiscountId != '" + DiscountType.CUTSOME_DISOUNT + "' order by tbdiscount.ficouponid desc";

        List<DiscountDBModel> discountDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, DiscountDBModel.class);
        if (ListUtil.isEmpty(discountDBModels)) {
            return new ArrayList<>();
        }
        return discountDBModels;
    }

    /**
     * 整单立减折扣集合
     */
    public static List<DiscountDBModel> optDiscountCutList(String fsShopGUID) {
        List<DiscountDBModel> discountCutList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, "where  fiStatus='1' and fsShopGUID='" + fsShopGUID + "' and ficouponid == '1' and fsDiscountId!='" + DiscountType.CASH + "' ", DiscountDBModel.class);
        if (ListUtil.isEmpty(discountCutList)) {
            return new ArrayList<>();
        }

        return discountCutList;
    }

    /**
     * 现金折
     */
    public static DiscountDBModel optDiscountCash(String fsShopGUID) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "where  fiStatus='1' and fsShopGUID='" + fsShopGUID + "' and fsDiscountId='" + DiscountType.CASH + "' " +
                "and ((datetime('now')>= fsStarDate and datetime('now')<=fsEndDate) or fiIsEffectiveDate=0)", DiscountDBModel.class);
    }

    /**
     * 自定义折扣
     */
    public static DiscountDBModel optDiscountCustom(String fsShopGUID) {
        return DBSimpleUtil.query(APPConfig.DB_MAIN, "where  fiStatus='1' and fsShopGUID='" + fsShopGUID + "' and fsDiscountId='" + DiscountType.CUTSOME_DISOUNT + "' " +
                "and ((datetime('now')>= fsStarDate and datetime('now')<=fsEndDate) or fiIsEffectiveDate=0)", DiscountDBModel.class);
    }

    /**
     * 正餐执行打折
     *
     * @param fsSellNo
     * @param fsmtableId
     * @param cleanAllDiscount
     * @param fsDiscountCutId
     * @param gift
     * @param useMemberPrice
     * @param fsDiscountId
     * @param userDBModel
     * @param reason
     * @param uniqList
     * @return
     */
    public static String dinnerDoDiscount(List<MenuItem> menuList, String fsSellNo, String fsmtableId, boolean cleanAllDiscount, String fsDiscountCutId, boolean gift, boolean useMemberPrice, int level, boolean useMemPriceWithoutMem, String fsDiscountId,
                                          UserDBModel userDBModel, String reason, List<String> uniqList) {
        return doDiscount(menuList, fsSellNo, fsmtableId, cleanAllDiscount, fsDiscountCutId, gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, -1, null);
    }

    public static String doDiscount(List<MenuItem> menuList, String fsSellNo, String fsmtableId, boolean cleanAllDiscount, String fsDiscountCutId, boolean gift, boolean useMemberPrice, int level, boolean useMemPriceWithoutMem, String fsDiscountId,
                                    UserDBModel userDBModel, String reason, List<String> uniqList, int fiDiscountRate, BigDecimal fdddv) {
        return doDiscount(menuList, fsSellNo, fsmtableId, cleanAllDiscount, fsDiscountCutId, gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, fiDiscountRate, fdddv, BigDecimal.ZERO);
    }

    /**
     * 执行打折
     *
     * @param fsSellNo
     * @param fsmtableId
     * @param cleanAllDiscount
     * @param fsDiscountCutId
     * @param gift
     * @param useMemberPrice
     * @param fsDiscountId
     * @param userDBModel
     * @param reason
     * @param uniqList
     * @param fiDiscountRate   折扣率 (不使用传:-1)
     * @param fdddv            立减金额(不使用传:null)
     * @return
     */
    public static String doDiscount(List<MenuItem> menuList, String fsSellNo, String fsmtableId, boolean cleanAllDiscount, String fsDiscountCutId, boolean gift, boolean useMemberPrice, int level, boolean useMemPriceWithoutMem, String fsDiscountId,
                                    UserDBModel userDBModel, String reason, List<String> uniqList, int fiDiscountRate, BigDecimal fdddv, BigDecimal disAmt) {
        return doDiscount(menuList, fsSellNo, fsmtableId, cleanAllDiscount, fsDiscountCutId, gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, fiDiscountRate, fdddv, disAmt, null);
    }

    public static String doDiscount(List<MenuItem> menuList, String fsSellNo, String fsmtableId, boolean cleanAllDiscount, String fsDiscountCutId, boolean gift, boolean useMemberPrice, int level, boolean useMemPriceWithoutMem, String fsDiscountId,
                                    UserDBModel userDBModel, String reason, List<String> uniqList, int fiDiscountRate, BigDecimal fdddv, BigDecimal disAmt, ArrayMap<String, BigDecimal> giftInfo) {
        return doDiscount(menuList, fsSellNo, fsmtableId, cleanAllDiscount, fsDiscountCutId, gift, useMemberPrice, level, useMemPriceWithoutMem, fsDiscountId, userDBModel, reason, uniqList, fiDiscountRate, fdddv, disAmt, giftInfo, null, null, null);
    }

    public static String doDiscount(List<MenuItem> menuList, String fsSellNo, String fsmtableId, boolean cleanAllDiscount,
                                    String fsDiscountCutId, boolean gift, boolean useMemberPrice, int level,
                                    boolean useMemPriceWithoutMem, String fsDiscountId,
                                    UserDBModel userDBModel, String reason, List<String> uniqList, int fiDiscountRate,
                                    BigDecimal fdddv, BigDecimal disAmt, ArrayMap<String, BigDecimal> giftInfo,
                                    Map<String, Map<String, List<String>>> buygiftRelation, Map<String, List<String>> ingredientsMapping,
                                    Map<String, List<String>> cleanCouponMapping) {

        String lockUniq = ServerCache.getInstance().tableLockCache.doLock(fsmtableId, fsSellNo, "打折");
        try {
            final OrderCache orderCache = OrderSession.getInstance().getOrder(fsSellNo);

            if (orderCache != null) {
                if (orderCache.orderStatus == OrderStatus.PAIED) {
                    return "订单已完成结账";
                }
            }
            //清空所有优惠--会员价、折扣、赠送
//            if (request.getBoolean("cleanAllDiscount")) {
            if (cleanAllDiscount) {
                DiscountBizUtil.cleanAllDiscount(menuList);
            }

            //整单立减折扣
            DiscountDBModel discountDBModelCut = null;
            if (!TextUtils.isEmpty(fsDiscountCutId)) {
                discountDBModelCut = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + fsDiscountCutId + "' and fiStatus = '1' ", DiscountDBModel.class);
                if (fdddv != null) {
                    discountDBModelCut.fdddv = fdddv;
                }
                if (discountDBModelCut != null && !DiscountBizUtil.dataIsEffectiveDate(discountDBModelCut)) {
                    return "整单立减折扣[" + discountDBModelCut.fsDiscountName + "]未生效";
                }
            }
            if (orderCache != null) {
                orderCache.selectOrderDiscountCut = CouponUtil.convertToDiscountBizModel(discountDBModelCut);
            }
            //如果要执行赠送、菜品会员价、菜品折扣，必须制定要优惠的菜品  (正餐订单必须要有已下单的菜）
            if (ListUtil.isEmpty(menuList)
                    && (gift || useMemberPrice || useMemPriceWithoutMem || !TextUtils.isEmpty(fsDiscountId))
                    && ListUtil.isEmpty(uniqList)
                    ) {  //正餐才判断是否有已下单的菜
                return "订单无已下单菜品";
            }

            //如果要执行赠送、菜品会员价、菜品折扣， 必须制定菜品
            if ((ListUtil.isEmpty(uniqList) && ListUtil.mapIsEmpty(ingredientsMapping)) && (gift || useMemberPrice || useMemPriceWithoutMem || !TextUtils.isEmpty(fsDiscountId))) {
                return "请选择菜品";
            }

            DiscountDBModel discountDBModel = null;
            if (!TextUtils.isEmpty(fsDiscountId)) {
                discountDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbdiscount where fsDiscountId = '" + fsDiscountId + "' and fiStatus = '1' ", DiscountDBModel.class);
                if (fiDiscountRate > 0) {
                    discountDBModel.fiDiscountRate = fiDiscountRate;
                }
                if (discountDBModel != null && !DiscountBizUtil.dataIsEffectiveDate(discountDBModel)) {
                    return "折扣[" + discountDBModel.fsDiscountName + "]未生效";
                }
            }

            int memberLevel = -1;
            String csId = "";
            String plusId = "";
            if (orderCache != null) {
                if (orderCache.isMember && orderCache.memberInfoS != null && orderCache.memberInfoS.level > 0) {
                    memberLevel = orderCache.memberInfoS.level;
                    csId = orderCache.memberInfoS.cs_id;
                    plusId = orderCache.memberInfoS.plusId;
                }
            }
            if (level > 0) {
                memberLevel = level;
            }

            if (useMemberPrice || gift || (giftInfo != null && giftInfo.size() > 0)) {
                //清除菜品的买减信息
                cleanBuyGift(uniqList, giftInfo, menuList);
            }

            if (!useMemberPrice && !gift && buygiftRelation != null && buygiftRelation.size() > 0) {
                doBuyGift(menuList, uniqList, orderCache, buygiftRelation);
            }

            if (disAmt != null && disAmt.compareTo(BigDecimal.ZERO) > 0) {
                DiscountBizUtil.discount(menuList, uniqList, gift, userDBModel.fsUserId, userDBModel.fsUserName, reason, useMemberPrice, useMemPriceWithoutMem, discountDBModel, fsDiscountId, null, memberLevel, disAmt, csId, plusId, ingredientsMapping, cleanCouponMapping);
            } else {
                DiscountBizUtil.discount(menuList, uniqList, gift, userDBModel.fsUserId, userDBModel.fsUserName, reason, useMemberPrice, useMemPriceWithoutMem, discountDBModel, fsDiscountId, null, memberLevel, giftInfo, orderCache, csId, plusId,ingredientsMapping, cleanCouponMapping);
            }


            if (orderCache != null) {
                //重新计算价格
                orderCache.plusAllMenuAmount();
                //存入报表
                OrderSession.getInstance().writeOrder(fsSellNo,true, "doDiscount");
//                OrderSession.getInstance().writeOrder(fsSellNo, true);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(lockUniq, fsmtableId, fsSellNo, "打折");
        }
        return "";
    }

    /**
     * 清除买减信息
     *
     * @param uniqList
     * @param menuList
     */
    public static void cleanBuyGift(List<String> uniqList, ArrayMap<String, BigDecimal> giftInfo, List<MenuItem> menuList) {
        if (ListUtil.isEmpty(uniqList) || ListUtil.isEmpty(menuList)) {
            return;
        }

        List<String> neadCleanMenuInfo = new ArrayList<>();

        for (String uniq : uniqList) {
            for (MenuItem menuItem : menuList) {
                if (TextUtils.equals(uniq, menuItem.menuBiz.uniq) && menuItem.menuBiz.bugGiftItem != null) {
                    neadCleanMenuInfo.add(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd);
                    break;
                }
            }
        }

        if (giftInfo != null && giftInfo.size() > 0) {
            for (String key : giftInfo.keySet()) {
                for (MenuItem menuItem : menuList) {
                    if (TextUtils.equals(key, menuItem.menuBiz.uniq) && menuItem.menuBiz.bugGiftItem != null) {
                        neadCleanMenuInfo.add(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd);
                        break;
                    }
                }
            }
        }

        if (ListUtil.isEmpty(neadCleanMenuInfo)) {
            return;
        }

        for (MenuItem menuItem : menuList) {
            if (menuItem.menuBiz.bugGiftItem != null && neadCleanMenuInfo.contains(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd)) {
                menuItem.cleanBuyGiftInfo();
                menuItem.calcTotal(false);
            }
        }
    }

    /**
     * 买减
     *
     * @param menuList
     * @param uniqList
     * @param orderCache
     * @param buygiftRelation
     */
    public static void doBuyGift(List<MenuItem> menuList, List<String> uniqList, OrderCache orderCache, Map<String, Map<String, List<String>>> buygiftRelation) {

        if (ListUtil.isEmpty(menuList) || buygiftRelation == null || buygiftRelation.size() <= 0) {
            return;
        }

        if (ListUtil.isEmpty(uniqList)) {
            uniqList = new ArrayList<>();
        }

        //每个订单中同样一个菜品只能使用一次买减
        //1、找出本次参与买减的所有菜品   List<String> usedBuyGiftMenu
        //2、将 usedBuyGiftMenu 中的菜品清空买减优惠信息

        List<String> usedBuyGiftMenu = new ArrayList<>();

        for (String fsBargainId : buygiftRelation.keySet()) {
            Map<String, List<String>> menuRelations = buygiftRelation.get(fsBargainId);
            for (String id : menuRelations.keySet()) {
                usedBuyGiftMenu.add(id);
            }
        }

        for (MenuItem menuItem : menuList) {
            if (menuItem == null) {
                continue;
            }
            if (menuItem.menuBiz.bugGiftItem == null) {
                continue;
            }
            if (usedBuyGiftMenu.contains(menuItem.itemID + "_" + menuItem.currentUnit.fiOrderUintCd)) {
                menuItem.cleanBuyGiftInfo();
                menuItem.calcTotal(false);
                continue;
            }

            for (String uniq : uniqList) {
                if (TextUtils.equals(uniq, menuItem.menuBiz.uniq)) {
                    menuItem.cleanBuyGiftInfo();
                    menuItem.calcTotal(false);
                    break;
                }
            }
        }
        String businessDate = "";
        if (orderCache == null) {
            businessDate = HostUtil.getHistoryBusineeDate("");
        } else {
            businessDate = orderCache.businessDate;
        }

        for (String fsBargainId : buygiftRelation.keySet()) {
            Map<String, List<String>> menuRelations = buygiftRelation.get(fsBargainId);
            CouponBuyGiftModel couponBuyGiftModel = OrderUtil.optBuyGift(businessDate, fsBargainId);
            if (couponBuyGiftModel == null) {
                continue;
            }
            if (menuRelations != null && menuRelations.size() > 0) {
                MenuItem menuItem;
                BigDecimal itemBuyCount = BigDecimal.ZERO;
                BigDecimal headCount = BigDecimal.ZERO;
                BigDecimal tailCount = BigDecimal.ZERO;
                for (String id : menuRelations.keySet()) {
                    BuyGiftItemModel bugGiftItem = OrderUtil.optBugGiftItem(fsBargainId, id.split("_")[0], id.split("_")[1]);
                    bugGiftItem.fsBargainName = couponBuyGiftModel.fsBargainName;
                    headCount = bugGiftItem.fdSaleQty;
                    tailCount = bugGiftItem.fdSaleQty_gift;
                    List<String> uniqStrList = menuRelations.get(id);
                    for (String uniq : uniqStrList) {
                        Iterator<MenuItem> menuItemIterator = menuList.iterator();
                        while (menuItemIterator.hasNext()) {
                            if (tailCount.compareTo(BigDecimal.ZERO) <= 0) {
                                break;
                            }
                            menuItem = menuItemIterator.next();

                            if (menuItem.hasAllVoid()) {
                                continue;
                            }

                            if (menuItem.isMenuTemporary() || menuItem.supportWeight() || menuItem.supportTimes()) {
                                continue;
                            }

                            if (TextUtils.equals(uniq, menuItem.menuBiz.uniq)) {

                                itemBuyCount = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);

                                if (itemBuyCount.compareTo(BigDecimal.ZERO) <= 0) {
                                    continue;
                                }

                                if (menuItem.supportWeight()) {
                                    itemBuyCount = BigDecimal.ONE;
                                }

                                if (headCount.compareTo(BigDecimal.ZERO) > 0) {
                                    if (headCount.compareTo(itemBuyCount) >= 0) {
                                        menuItem.disGift();
                                        menuItem.useMemberPrice = false;
                                        menuItem.menuBiz.bugGiftItem = bugGiftItem;
                                        menuItem.menuBiz.decreasConfig(64);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --1--- 当前菜品购买数量不足头菜时，全做头菜  decreasConfig" + menuItem.menuBiz.buyNum);

                                        headCount = headCount.subtract(itemBuyCount);
                                    } else {
                                        //大于头菜时，需要做拆分处理   拆出所剩的头菜，剩余菜品数理再和尾菜做比对
                                        MenuItem menuItemClone = menuItem.clone();
                                        menuItemClone.updateUniq();
                                        menuItemClone.menuBiz.buyNum = headCount;
                                        menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                        menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                        menuItemClone.useMemberPrice = false;
                                        menuItemClone.menuBiz.bugGiftItem = bugGiftItem;
                                        menuItemClone.menuBiz.decreasConfig(64);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --2--- 大于头菜时，需要做拆分处理   拆出所剩的头菜，剩余菜品数理再和尾菜做比对  decreasConfig" + menuItemClone.menuBiz.buyNum);

                                        menuItemClone.disGift();
                                        menuItemClone.calcTotal(false);

                                        if (DBOrderConfig.useKdsService()) {
                                            // 通知 KDS 菜品拆分
                                            KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                        }

                                        if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            orderCache.originMenuList.add(menuItemClone);
                                        } else {
                                            menuList.add(menuItemClone);
                                        }
                                        headCount = headCount.subtract(headCount);

                                        if (tailCount.compareTo(itemBuyCount.subtract(menuItemClone.menuBiz.buyNum)) >= 0) {
                                            //拆出的菜不足尾菜部分，全做尾菜处理
                                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemClone.menuBiz.buyNum);
                                            menuItem.useMemberPrice = false;
                                            menuItem.menuBiz.bugGiftItem = bugGiftItem;
                                            menuItem.menuBiz.addConfig(64);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --3--- 拆出的菜不足尾菜部分，全做尾菜处理  addConfig" + menuItem.menuBiz.buyNum);

                                            menuItem.disGift();
                                            menuItem.calcTotal(false);

                                            tailCount = tailCount.subtract(menuItem.menuBiz.buyNum);
                                        } else {
                                            //拆出的菜大于尾菜部分，再做拆分处理
                                            MenuItem menuItemCloneTail = menuItem.clone();
                                            menuItemCloneTail.updateUniq();
                                            menuItemCloneTail.menuBiz.buyNum = tailCount;
                                            menuItemCloneTail.menuBiz.voidNum = BigDecimal.ZERO;
                                            menuItemCloneTail.menuBiz.giftNum = BigDecimal.ZERO;
                                            menuItemCloneTail.useMemberPrice = false;
                                            menuItemCloneTail.menuBiz.bugGiftItem = bugGiftItem;
                                            menuItemCloneTail.menuBiz.addConfig(64);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --4--- 拆出的菜大于尾菜部分，再做拆分处理  addConfig" + menuItemCloneTail.menuBiz.buyNum);

                                            menuItemCloneTail.disGift();
                                            menuItemCloneTail.calcTotal(false);

                                            if (DBOrderConfig.useKdsService()) {
                                                // 通知 KDS 菜品拆分
                                                KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemCloneTail.menuBiz.uniq, menuItemCloneTail.menuBiz.buyNum, 2);
                                            }

                                            if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                                orderCache.originMenuList.add(menuItemCloneTail);
                                            } else {
                                                menuList.add(menuItemCloneTail);
                                            }
                                            tailCount = tailCount.subtract(tailCount);

                                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemClone.menuBiz.buyNum).subtract(menuItemCloneTail.menuBiz.buyNum);
                                            menuItem.calcTotal(false);
                                            LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --5--- 多出部分不做额外处理 " + menuItem.menuBiz.buyNum);
                                        }
                                    }
                                } else if (tailCount.compareTo(BigDecimal.ZERO) > 0) {

                                    if (tailCount.compareTo(itemBuyCount.subtract(headCount)) >= 0) {
                                        //头菜已分完，当前菜品又不足尾菜部分，全做尾菜处理
                                        menuItem.disGift();
                                        menuItem.useMemberPrice = false;
                                        menuItem.menuBiz.bugGiftItem = bugGiftItem;
                                        menuItem.menuBiz.addConfig(64);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItem.menuBiz.uniq + " --6--- 头菜已分完，当前菜品又不足尾菜部分，全做尾菜处理  addConfig" + menuItem.menuBiz.buyNum);
                                        menuItem.calcTotal(false);
                                        tailCount = tailCount.subtract(itemBuyCount);
                                    } else {
                                        //头菜已分完，当前菜品大于尾菜部分，再做拆分处理
                                        MenuItem menuItemCloneTail = menuItem.clone();
                                        menuItemCloneTail.updateUniq();
                                        menuItemCloneTail.menuBiz.buyNum = tailCount;
                                        menuItemCloneTail.menuBiz.voidNum = BigDecimal.ZERO;
                                        menuItemCloneTail.menuBiz.giftNum = BigDecimal.ZERO;
                                        menuItemCloneTail.useMemberPrice = false;
                                        menuItemCloneTail.menuBiz.bugGiftItem = bugGiftItem;
                                        menuItemCloneTail.menuBiz.addConfig(64);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItemCloneTail.menuBiz.uniq + " --7--- 头菜已分完，当前菜品大于尾菜部分，再做拆分处理  addConfig" + menuItemCloneTail.menuBiz.buyNum);
                                        menuItemCloneTail.disGift();
                                        menuItemCloneTail.calcTotal(false);

                                        if (DBOrderConfig.useKdsService()) {
                                            // 通知 KDS 菜品拆分
                                            KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemCloneTail.menuBiz.uniq, menuItemCloneTail.menuBiz.buyNum, 2);
                                        }

                                        if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                            orderCache.originMenuList.add(menuItemCloneTail);
                                        } else {
                                            menuList.add(menuItemCloneTail);
                                        }
                                        tailCount = tailCount.subtract(tailCount);

                                        menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(menuItemCloneTail.menuBiz.buyNum);
                                        menuItem.calcTotal(false);
                                        LogUtil.logBusiness("菜品买减分菜：" + menuItemCloneTail.menuBiz.uniq + " --8--- 尾菜已分完，剩余菜品不做额外处理 " + menuItem.menuBiz.buyNum);

                                    }
                                }
                            }

                        }
                    }


                }
            }
        }

    }


    /**
     * 打折--遍历菜品，执行优惠操作
     *
     * @param menuItemList
     * @param uniqList
     * @param gift
     * @param fsUserId
     * @param fsUserName
     * @param reason
     * @param useMemberPrice
     * @param discountDBModel
     * @param fsDiscountId
     * @param unOrderMenuItemList
     */

    public static void discount(List<MenuItem> menuItemList, List<String> uniqList, boolean gift, String fsUserId, String fsUserName,
                                String reason, boolean useMemberPrice, boolean useMemPriceWithoutMem,
                                DiscountDBModel discountDBModel, String fsDiscountId, List<MenuItem> unOrderMenuItemList,
                                int memberLevel, ArrayMap<String, BigDecimal> giftInfo, OrderCache orderCache, String csId, String plusId,
                                Map<String, List<String>> ingredientsMapping, Map<String, List<String>> cleanCouponMapping) {
        if (menuItemList == null) {
            menuItemList = new ArrayList<>();
        }
        if (unOrderMenuItemList == null) {
            unOrderMenuItemList = new ArrayList<>();
        }

        LogUtil.logBusiness("折扣", "打折菜品数量:" + menuItemList.size() + ",uniq：" + uniqList +
                ",gift:" + gift + ",fsUserId:" + fsUserId + ",fsUserName:" + fsUserName + ",reason:" + reason +
                ",useMemberPrice:" + useMemberPrice + ",useMemPriceWithoutMem" + useMemPriceWithoutMem +
                ",fsDiscountId:" + fsDiscountId + ",memberLevel:" + memberLevel + ",order:" + (orderCache == null ? "未下单订单" : orderCache.orderID) +
                ",ingredientsMapping:" + ingredientsMapping);

        for (MenuItem menuItem : menuItemList) {
            if (menuItem == null) {
                continue;
            }

            LogUtil.logBusiness("折扣", "菜品【" + menuItem.name + "," + menuItem.itemID + "," +
                    menuItem.currentUnit.fsOrderUint + "," + menuItem.currentUnit.fiOrderUintCd + "】进行折扣【" +
                    JSON.toJSONString(discountDBModel) + "】");

            //删除重复菜品
            if (!ListUtil.isEmpty(unOrderMenuItemList)) {
                for (int j = 0; j < unOrderMenuItemList.size(); j++) {
                    MenuItem tempMenuItem = unOrderMenuItemList.get(j);
                    if (tempMenuItem == null) {
                        continue;
                    }

                    if (TextUtils.equals(menuItem.menuBiz.uniq, tempMenuItem.menuBiz.uniq)) {
                        unOrderMenuItemList.remove(j);
                        break;
                    }
                }
            }

            // 先清除指定优惠，再做优惠
            cleanMenuCoupon(menuItem, cleanCouponMapping);

            // 有配料要折扣
            if (!ListUtil.mapIsEmpty(ingredientsMapping)) {
                List<String> ingredientList = ingredientsMapping.get(menuItem.menuBiz.uniq);
                if (!ListUtil.isEmpty(ingredientList)) {
                    for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                        for (String ingredientUniq : ingredientList) {
                            if (!TextUtils.equals(modifier.menuBiz.uniq, ingredientUniq)) {
                                continue;
                            }

                            LogUtil.logBusiness("折扣", "配料【" + modifier.name + "," + modifier.itemID + "," +
                                    modifier.currentUnit.fsOrderUint + "," + modifier.currentUnit.fiOrderUintCd + "】进行折扣【" +
                                    JSON.toJSONString(discountDBModel) + "】");

                            if (gift) {// 赠送
                                if (modifier.doGift(fsUserId, "", reason, false)) {
                                    modifier.cleanBuyGiftInfo();
                                    modifier.calcTotal(false);
                                }
                            } else {
                                modifier.disGift(false);
                                giveDiscountToMenu(reason, discountDBModel, fsDiscountId, modifier, menuItem);
                                modifier.calcTotal(false);
                            }
                        }
                    }
                }
            }

            if (uniqList.contains(menuItem.menuBiz.uniq)) {
                if (gift) {
                    //赠送菜品---没有给数量时，默认是全部赠送
                    if (giftInfo != null && giftInfo.get(menuItem.menuBiz.uniq) != null) {
                        //赠送数量<=0时，认为是取消赠送
                        if (giftInfo.get(menuItem.menuBiz.uniq).compareTo(BigDecimal.ZERO) <= 0) {

                            if (menuItem.doGift(fsUserId, "", reason)) {
                                menuItem.calcTotal(false);
                            }
                        } else if (menuItem.menuBiz.giftNum.compareTo(BigDecimal.ZERO) > 0) {
                            //该菜品是赠送状态--再次提交的赠送数量小于已赠送数量---->取消部分赠送
                            if (giftInfo.get(menuItem.menuBiz.uniq).compareTo(menuItem.menuBiz.giftNum) < 0) {
                                MenuItem menuItemClone = menuItem.clone();
                                menuItemClone.updateUniq();
                                menuItemClone.menuBiz.buyNum = menuItemClone.menuBiz.buyNum.subtract(giftInfo.get(menuItem.menuBiz.uniq));
                                menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                                menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                                menuItemClone.disGift();
                                menuItemClone.calcTotal(false);

                                if (DBOrderConfig.useKdsService()) {
                                    // 通知 KDS 菜品拆分
                                    KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                                }

                                menuItem.menuBiz.buyNum = giftInfo.get(menuItem.menuBiz.uniq);
                                if (menuItem.doGift(fsUserId, "", reason)) {
                                    menuItem.cleanBuyGiftInfo();
                                    menuItem.calcTotal(false);
                                }
                                if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                    orderCache.originMenuList.add(menuItemClone);
                                } else {
                                    menuItemList.add(menuItemClone);
                                }

                                /* 调整划菜数量 */
                                // 已划菜数量
                                BigDecimal delimited = menuItem.menuBiz.delimitNum;
                                // 划菜数量优先分配到赠送的菜品
                                if (menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).compareTo(delimited) >= 0) {
                                    menuItem.menuBiz.delimitNum = delimited;
                                    menuItemClone.menuBiz.delimitNum = BigDecimal.ZERO;
                                } else {
                                    menuItem.menuBiz.delimitNum = menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum);
                                    menuItemClone.menuBiz.delimitNum = delimited.subtract(menuItem.menuBiz.delimitNum);
                                }
                            }
                        } else if (giftInfo.get(menuItem.menuBiz.uniq).compareTo(menuItem.menuBiz.buyNum.subtract(menuItem.menuBiz.voidNum).subtract(menuItem.menuBiz.giftNum)) < 0) {
                            //非赠送菜品---赠送数量小于菜品数量时，认为是赠送部分菜品
                            MenuItem menuItemClone = menuItem.clone();
                            menuItemClone.updateUniq();
                            menuItemClone.menuBiz.buyNum = giftInfo.get(menuItem.menuBiz.uniq);
                            menuItemClone.menuBiz.voidNum = BigDecimal.ZERO;
                            menuItemClone.menuBiz.giftNum = BigDecimal.ZERO;
                            if (menuItemClone.doGift(fsUserId, "", reason)) {
                                menuItem.cleanBuyGiftInfo();
                                menuItemClone.calcTotal(false);
                            }
                            menuItem.menuBiz.buyNum = menuItem.menuBiz.buyNum.subtract(giftInfo.get(menuItem.menuBiz.uniq));
                            menuItem.calcTotal(false);

                            if (DBOrderConfig.useKdsService()) {
                                // 通知 KDS 菜品拆分
                                KdsManager.getInstance().splitMenu(menuItem.menuBiz.uniq, menuItemClone.menuBiz.uniq, menuItemClone.menuBiz.buyNum, 2);
                            }

                            if (orderCache != null && orderCache.isOrderedSeqNo(menuItem.menuBiz.orderSeqID)) {
                                orderCache.originMenuList.add(menuItemClone);
                            } else {
                                menuItemList.add(menuItemClone);
                            }

                            /* 调整划菜数量 */
                            // 已划菜数量
                            BigDecimal delimited = menuItem.menuBiz.delimitNum;
                            // 划菜数量优先分配到赠送的菜品
                            if (menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum).compareTo(delimited) >= 0) {
                                menuItemClone.menuBiz.delimitNum = delimited;
                                menuItem.menuBiz.delimitNum = BigDecimal.ZERO;
                            } else {
                                menuItemClone.menuBiz.delimitNum = menuItemClone.menuBiz.buyNum.subtract(menuItemClone.menuBiz.voidNum);
                                menuItem.menuBiz.delimitNum = delimited.subtract(menuItemClone.menuBiz.delimitNum);
                            }
                        } else {
                            //非赠送菜品---赠送数量大于等于菜品数量时，认为是赠送全部菜品
                            if (menuItem.doGift(fsUserId, "", reason)) {
                                menuItem.cleanBuyGiftInfo();
                                menuItem.calcTotal(false);
                            }
                        }
                    } else {
                        if (menuItem.doGift(fsUserId, "", reason)) {
                            menuItem.cleanBuyGiftInfo();
                            menuItem.calcTotal(false);
                        }
                    }
                } else {
                    menuItem.useMemberPrice = useMemberPrice;
                    menuItem.disGift(false);

                    if (useMemPriceWithoutMem) {
                        // 一键结算会员价，使用菜品规格的会员价
                        menuItem.useMemberPrice = true;
                        menuItem.cleanBuyGiftInfo();
                        menuItem.menuBiz.addConfig(32);
                    } else {
                        menuItem.menuBiz.decreasConfig(32);
                        if (useMemberPrice && memberLevel > 0 && !menuItem.supportTimes() && !menuItem.isMenuTemporary()) {   //支持多等级会员价
                            menuItem.currentUnit.fdVIPPrice = MenuItemVipPriceUtil.getMemberVipPrice(menuItem.itemID, menuItem.currentUnit.fiOrderUintCd, memberLevel, csId, plusId);
                        }
                    }

                    giveDiscountToMenu(reason, discountDBModel, fsDiscountId, menuItem, null);
                    menuItem.calcTotal(useMemberPrice);
                }
            }
        }

        if (!ListUtil.isEmpty(unOrderMenuItemList)) {
            discount(unOrderMenuItemList, uniqList, gift, fsUserId, fsUserName, reason, useMemberPrice, useMemPriceWithoutMem,
                    discountDBModel, fsDiscountId, null, memberLevel, giftInfo, orderCache, csId, plusId, ingredientsMapping, cleanCouponMapping);
        }
    }

    /**
     * 折扣落到菜/配料上
     *
     * @param target 菜品/配料
     * @param father 单品或套餐时请传null，配料时传主菜（配料的可折扣属性读主菜的）
     */
    private static void giveDiscountToMenu(String reason, DiscountDBModel discountDBModel, String fsDiscountId,
                                           MenuItem target, MenuItem father) {
        // 配料的可折扣属性读主菜的
        MenuItem checkSupport = father == null ? target : father;
        if (checkSupport.supportDiscount()) { // 菜品可折扣
            if (discountDBModel != null && discountDBModel.ficouponid != 2) {
                // 缓存已赋值的折扣
                int rate = discountDBModel.fiDiscountRate;

                //非整单打折的折扣要校验该菜品是否支持该折扣
                String sql = "select tbdiscount.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,tbdiscountitem.fiDiscountRate fiDiscountRate from tbdiscount inner join tbdiscountitem on tbdiscountitem.fsDiscountId=tbdiscount.fsDiscountId where tbdiscount.fsDiscountId<>'99999' and tbdiscountitem.fsDiscountId='" + fsDiscountId + "' and tbdiscountitem.fiStatus ='1' and tbdiscount.fiStatus ='1' and tbdiscountitem.fiOrderUintCd='%1$s' and tbdiscountitem.fiItemCd='%2$s' order by tbdiscount.fsDiscountId asc";
                DiscountDBModel discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.currentUnit.fiOrderUintCd, target.itemID), DiscountDBModel.class);
                if (discount == null) {
                    sql = "select dismenucls.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,dismenucls.fiDiscountRate fiDiscountRate from (select * from tbdiscountmenucls where fsMenuClsId = (select fsMenuClsId from tbmenuitem where fiitemcd = '%1$s') and fistatus = '1' and fsdiscountid = '%2$s' ) dismenucls left join tbdiscount " +
                            "on tbdiscount.fsdiscountid = dismenucls.fsdiscountid and tbdiscount.fistatus = '1' ";
                    discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.itemID, fsDiscountId), DiscountDBModel.class);
                }

                // 兼容后台自定义折扣可能为部分折扣的情况
                if (discount != null && TextUtils.equals(DiscountType.CUTSOME_DISOUNT, discount.fsDiscountId)) {
                    discount.fiDiscountRate = rate;
                }

                target.giveDiscount(discount, reason, "", "", false);
            } else {
                target.giveDiscount(discountDBModel, reason, "", "", false);
            }
        } else { // 菜品不可折扣
            // 整单打折 && 不可折扣菜品可参与该整单打折 -> 可折
            if (discountDBModel != null && discountDBModel.ficouponid == 2 && discountDBModel.fiIsDisMenu == 1) {
                target.giveDiscount(discountDBModel, reason, "", "", false);
            }
        }
    }

    /**
     * 清空所有优惠
     *
     * @param menuItemList
     */
    public static void cleanAllDiscount(List<MenuItem> menuItemList) {
        if (!ListUtil.isEmpty(menuItemList)) {
            for (MenuItem menuItem : menuItemList) {
                menuItem.cleanAllPrivilege();
                // 清除配料上的优惠
                if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
                    cleanAllDiscount(menuItem.menuBiz.selectedModifier);
                }
            }
        }
    }


    /**
     * 检查数据是否生效
     * P
     *
     * @return boolean | true 菜品已生效；false: 菜品还未生效
     */
    public static boolean dataIsEffectiveDate(DiscountDBModel discountDBModel) {
        if (discountDBModel.fiIsEffectiveDate == 0) {
            return true;
        }
        long startTime = DateTimeUtil.strToDate(discountDBModel.fsStarDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
        long endTime = DateTimeUtil.strToDate(discountDBModel.fsEndDate, DateTimeUtil.YYYYMMDDHHMM).getTime();
        return DateTimeUtil.isBetweenMillis(startTime, endTime);
    }

    /**
     * 非会员是否可使用会员价
     *
     * @return boolean | true: 开启; false: 关闭
     */
    public static boolean canUseMemPriceWithoutMem() {
        String memberConfigStr = DBMetaUtil.getConfig(META.MEMBER_CONFIG, "");
        if (TextUtils.isEmpty(memberConfigStr)) {
            RunTimeLog.addLog(RunTimeLog.USE_MEM_PRICE_WITHOUT_MEM, "未查询到门店会员配置，默认开启一键结算会员价");
            return true;
        }

        try {
            MemberConfig config = JSON.parseObject(memberConfigStr, MemberConfig.class);
            if (config != null && config.is_open == 1) {
                RunTimeLog.addLog(RunTimeLog.USE_MEM_PRICE_WITHOUT_MEM, "门店已开启 CRM 会员，关闭一键结算会员价");
                return false;
            } else {
                RunTimeLog.addLog(RunTimeLog.USE_MEM_PRICE_WITHOUT_MEM, "门店未开启 CRM 会员，开启一键结算会员价");
                return true;
            }
        } catch (Exception ex) {
            RunTimeLog.addLog(RunTimeLog.USE_MEM_PRICE_WITHOUT_MEM, "门店会员配置异常，默认开启一键结算会员价");
            return true;
        }
    }

    public static void discount(List<MenuItem> menuItemList, List<String> uniqList, boolean gift, String fsUserId, String fsUserName,
                                String reason, boolean useMemberPrice, boolean useMemPriceWithoutMem,
                                DiscountDBModel discountDBModel, String fsDiscountId, List<MenuItem> unOrderMenuItemList,
                                int memberLevel, BigDecimal discountAmt, String csId,  String plusId,
                                Map<String, List<String>> ingredientsMapping, Map<String, List<String>> cleanCouponMapping) {
        if (menuItemList == null) {
            menuItemList = new ArrayList<>();
        }
        if (unOrderMenuItemList == null) {
            unOrderMenuItemList = new ArrayList<>();
        }

        LogUtil.logBusiness("折扣", "打折菜品数量:" + menuItemList.size() + ",uniq：" + uniqList +
                ",gift:" + gift + ",fsUserId:" + fsUserId + ",fsUserName:" + fsUserName + ",reason:" + reason +
                ",useMemberPrice:" + useMemberPrice + ",useMemPriceWithoutMem" + useMemPriceWithoutMem +
                ",fsDiscountId:" + fsDiscountId + ",memberLevel:" + memberLevel + ",discountAmt:" + discountAmt +
                ",ingredientsMapping:" + ingredientsMapping);

        // 金额折转换的折扣率
        BigDecimal disCashRate = BigDecimal.ZERO;
        disCashRate = calcDisCashRate(menuItemList, uniqList, ingredientsMapping, discountDBModel, discountAmt, disCashRate);

        BigDecimal hasDisAmt = BigDecimal.ZERO;

        for (MenuItem menuItem : menuItemList) {
            if (menuItem == null) {
                continue;
            }
            LogUtil.logBusiness("折扣", "菜品【" + menuItem.name + "," + menuItem.itemID + "," +
                    menuItem.currentUnit.fsOrderUint + "," + menuItem.currentUnit.fiOrderUintCd + "】进行折扣【" +
                    JSON.toJSONString(discountDBModel) + "】");

            //删除重复菜品
            if (!ListUtil.isEmpty(unOrderMenuItemList)) {
                for (int j = 0; j < unOrderMenuItemList.size(); j++) {
                    MenuItem tempMenuItem = unOrderMenuItemList.get(j);
                    if (tempMenuItem == null) {
                        continue;
                    }

                    if (TextUtils.equals(menuItem.menuBiz.uniq, tempMenuItem.menuBiz.uniq)) {
                        unOrderMenuItemList.remove(j);
                        break;
                    }
                }
            }

            // 先清除指定优惠，再做优惠
            cleanMenuCoupon(menuItem, cleanCouponMapping);

            // 有配料要折扣
            if (!ListUtil.mapIsEmpty(ingredientsMapping)) {
                List<String> ingredientList = ingredientsMapping.get(menuItem.menuBiz.uniq);
                if (!ListUtil.isEmpty(ingredientList)) {
                    for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                        for (String ingredientUniq : ingredientList) {
                            if (!TextUtils.equals(modifier.menuBiz.uniq, ingredientUniq)) {
                                continue;
                            }

                            LogUtil.logBusiness("折扣", "配料【" + modifier.name + "," + modifier.itemID + "," +
                                    modifier.currentUnit.fsOrderUint + "," + modifier.currentUnit.fiOrderUintCd + "】进行折扣【" +
                                    JSON.toJSONString(discountDBModel) + "】");

                            if (gift) {// 赠送
                                if (modifier.doGift(fsUserId, "", reason, false)) {
                                    modifier.cleanBuyGiftInfo();
                                    modifier.calcTotal(false);
                                }
                            } else {
                                modifier.disGift(false);
                                giveDiscountToMenu(reason, discountDBModel, fsDiscountId, discountAmt, disCashRate, modifier, menuItem);
                                modifier.calcTotal(false);

                                // 统计已折扣的金额
                                if (modifier.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(modifier.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, modifier.menuBiz.selectDiscount.fsDiscountId)) {
                                    hasDisAmt = hasDisAmt.add(modifier.menuBiz.discountAmount);
                                }
                            }
                        }
                    }
                }
            }

            if (uniqList.contains(menuItem.menuBiz.uniq)) {
                if (gift) {
                    menuItem.cleanBuyGiftInfo();
                    if (menuItem.doGift(fsUserId, "", reason)) {
                        menuItem.calcTotal(false);
                    }
                } else {
                    menuItem.useMemberPrice = useMemberPrice;
                    menuItem.disGift(false);

                    if (useMemPriceWithoutMem) {
                        // 一键结算会员价，使用菜品规格的会员价
                        menuItem.useMemberPrice = true;
                        menuItem.menuBiz.addConfig(32);
                        menuItem.cleanBuyGiftInfo();
                    } else {
                        menuItem.menuBiz.decreasConfig(32);
                        if (useMemberPrice && memberLevel > 0 && !menuItem.supportTimes() && !menuItem.isMenuTemporary()) {   //支持多等级会员价
                            menuItem.currentUnit.fdVIPPrice = MenuItemVipPriceUtil.getMemberVipPrice(menuItem.itemID, menuItem.currentUnit.fiOrderUintCd, memberLevel, csId, plusId);
                        }
                    }

                    giveDiscountToMenu(reason, discountDBModel, fsDiscountId, discountAmt, disCashRate, menuItem, null);
                    menuItem.calcTotal(useMemberPrice);

                    // 统计已折扣的金额
                    if (menuItem.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(menuItem.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, menuItem.menuBiz.selectDiscount.fsDiscountId)) {
                        hasDisAmt = hasDisAmt.add(menuItem.menuBiz.discountAmount);
                    }
                }
            }
        }

        // 由于折扣率保留小数，所有菜品按照折扣率折扣后，是否有未折扣的金额，调整菜品折扣金额
        checkLeftDiscount(menuItemList, uniqList, ingredientsMapping, useMemberPrice, discountAmt, hasDisAmt);

        if (!ListUtil.isEmpty(unOrderMenuItemList)) {
            discount(unOrderMenuItemList, uniqList, gift, fsUserId, fsUserName, reason, useMemberPrice, useMemPriceWithoutMem,
                    discountDBModel, fsDiscountId, null, memberLevel, discountAmt, csId, plusId, ingredientsMapping, cleanCouponMapping);
        }
    }

    /**
     * 折扣落到菜/配料上
     *
     * @param target 菜品/配料
     * @param father 单品或套餐时请传null，配料时传主菜（配料的可折扣属性读主菜的）
     */
    private static void giveDiscountToMenu(String reason, DiscountDBModel discountDBModel, String fsDiscountId, BigDecimal discountAmt,
                                           BigDecimal disCashRate, MenuItem target, MenuItem father) {
        // 配料的可折扣属性读主菜的
        MenuItem checkSupport = father == null ? target : father;
        if (checkSupport.supportDiscount()) {
            if (discountDBModel != null && discountDBModel.ficouponid != 2) {
                //非整单打折的折扣要校验该菜品是否支持该折扣
                String sql = "select tbdiscount.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,tbdiscountitem.fiDiscountRate fiDiscountRate from tbdiscount inner join tbdiscountitem on tbdiscountitem.fsDiscountId=tbdiscount.fsDiscountId where tbdiscountitem.fsDiscountId='" + fsDiscountId + "' and tbdiscountitem.fiStatus ='1' and tbdiscount.fiStatus ='1' and tbdiscountitem.fiOrderUintCd='%1$s' and tbdiscountitem.fiItemCd='%2$s' order by tbdiscount.fsDiscountId asc";
                DiscountDBModel discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.currentUnit.fiOrderUintCd, target.itemID), DiscountDBModel.class);
                if (discount == null) {
                    sql = "select dismenucls.fsDiscountId fsDiscountId,tbdiscount.fsDiscountName fsDiscountName,tbdiscount.fiIsVIPUse fiIsVIPUse,dismenucls.fiDiscountRate fiDiscountRate from (select * from tbdiscountmenucls where fsMenuClsId = (select fsMenuClsId from tbmenuitem where fiitemcd = '%1$s') and fistatus = '1' and fsdiscountid = '%2$s' ) dismenucls left join tbdiscount " +
                            "on tbdiscount.fsdiscountid = dismenucls.fsdiscountid and tbdiscount.fistatus = '1' ";
                    discount = DBSimpleUtil.query(APPConfig.DB_MAIN, String.format(sql, target.itemID, fsDiscountId), DiscountDBModel.class);
                }
                if (discount != null && TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discount.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discount, disCashRate, reason, "", "", false);
                } else {
                    target.giveDiscount(discount, reason, "", "", false);
                }
            } else {// 整单打折
                if (discountDBModel != null && TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discountDBModel.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discountDBModel, disCashRate, reason, "", "", false);
                } else {
                    target.giveDiscount(discountDBModel, reason, "", "", false);
                }
            }
        } else { // 菜品不可折扣
            // 整单打折 && 不可折扣菜品可参与该整单打折 -> 可折
            if (discountDBModel != null && discountDBModel.ficouponid == 2 && discountDBModel.fiIsDisMenu == 1) {
                if (TextUtils.equals(fsDiscountId, DiscountType.CASH) && discountAmt.compareTo(BigDecimal.ZERO) > 0) {
                    // 金额折折扣
                    discountDBModel.fiDiscountRate = disCashRate.multiply(BizConstant.HUNDREND).setScale(0, RoundingMode.HALF_UP).intValue();
                    target.giveDiscountCash(discountDBModel, disCashRate, reason, "", "", false);
                } else {
                    target.giveDiscount(discountDBModel, reason, "", "", false);
                }
            }
        }
    }

    /**
     * 由于折扣率保留小数，所有菜品按照折扣率折扣后，是否有未折扣的金额，调整菜品折扣金额
     */
    private static void checkLeftDiscount(List<MenuItem> menuItemList, List<String> uniqList, Map<String, List<String>> ingredientsMapping,
                                          boolean useMemberPrice, BigDecimal discountAmt, BigDecimal hasDisAmt) {
        BigDecimal leftDis = discountAmt.subtract(hasDisAmt);
        if (leftDis.compareTo(BigDecimal.ZERO) != 0) {
            // 未能分配的折扣金额，由菜品依次折扣
            for (MenuItem menuItem : menuItemList) {
                if (menuItem == null) {
                    continue;
                }
                boolean needCalc = false;
                if (uniqList.contains(menuItem.menuBiz.uniq)) {
                    // 仅菜品支持折扣，且进行金额折的时候，分摊金额折
                    if (menuItem.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(menuItem.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, menuItem.menuBiz.selectDiscount.fsDiscountId)) {
                        // 菜品还可以折扣的金额
                        BigDecimal canDisAmt = menuItem.menuBiz.totalPrice;
                        if (canDisAmt.compareTo(leftDis) > 0) {
                            menuItem.menuBiz.discountAmount = menuItem.menuBiz.discountAmount.add(leftDis);
                            leftDis = BigDecimal.ZERO;
                        } else {
                            menuItem.menuBiz.discountAmount = menuItem.menuBiz.discountAmount.add(canDisAmt);
                            leftDis = leftDis.subtract(canDisAmt);
                        }
                    }
                    needCalc = true;
                }

                List<String> ingredientList = ingredientsMapping.get(menuItem.menuBiz.uniq);
                if (!ListUtil.isEmpty(ingredientList)) {
                    for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                        for (String ingredientUniq : ingredientList) {
                            if (!TextUtils.equals(ingredientUniq, modifier.menuBiz.uniq)) {
                                continue;
                            }
                            if (modifier.menuBiz.selectDiscount != null && (menuItem.supportDiscount() || OrderUtil.supportFullOrderDiscount(modifier.menuBiz.selectDiscount, menuItem)) && TextUtils.equals(DiscountType.CASH, modifier.menuBiz.selectDiscount.fsDiscountId)) {
                                // 菜品还可以折扣的金额
                                BigDecimal canDisAmt = modifier.menuBiz.totalPrice;
                                if (canDisAmt.compareTo(leftDis) > 0) {
                                    modifier.menuBiz.discountAmount = modifier.menuBiz.discountAmount.add(leftDis);
                                    leftDis = BigDecimal.ZERO;
                                } else {
                                    modifier.menuBiz.discountAmount = modifier.menuBiz.discountAmount.add(canDisAmt);
                                    leftDis = leftDis.subtract(canDisAmt);
                                }
                            }
                            needCalc = true;
                        }
                    }
                }

                if (needCalc) {
                    menuItem.calcTotal(useMemberPrice);
                }
            }
        }
    }

    private static BigDecimal calcDisCashRate(List<MenuItem> menuItemList, List<String> uniqList, Map<String, List<String>> ingredientsMapping,
                                              DiscountDBModel discountDBModel, BigDecimal discountAmt, BigDecimal disCashRate) {
        if (discountDBModel != null && TextUtils.equals(discountDBModel.fsDiscountId, DiscountType.CASH)) {
            BigDecimal total = BigDecimal.ZERO;
            for (MenuItem item : menuItemList) {
                if (item == null) {
                    continue;
                }

                List<String> ingredientList = ingredientsMapping.get(item.menuBiz.uniq);
                if (!ListUtil.isEmpty(ingredientList)) {
                    for (MenuItem modifier : item.menuBiz.selectedModifier) {
                        for (String ingredientUniq : ingredientList) {
                            if (!TextUtils.equals(ingredientUniq, modifier.menuBiz.uniq)) {
                                continue;
                            }

                            if (discountDBModel.ficouponid != 2) {
                                //非整单折扣要判断菜品是否支持此折扣
                                String sql = "select * from (select fsdiscountid from tbDiscountItem where fiItemCd = '" + modifier.itemID + "' and fiOrderUintCd = '" + modifier.currentUnit.fiOrderUintCd + "' and fiStatus = '1' union all select fsdiscountid from tbdiscountmenucls where fsMenuClsId = '" + modifier.categoryCode + "' and fistatus = '1')";
                                List<String> discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                                if (!discountIDList.contains(DiscountType.CASH)) {
                                    continue;
                                }
                            } else {
                                // 整单打折要判断该折扣是否支持不可折扣菜品参与打折
                                // 不可折扣菜品不参与该整单打折 && 菜品不可折扣 -> 不折
                                if (discountDBModel.fiIsDisMenu == 0 && !item.supportDiscount()) {
                                    continue;
                                }
                            }

                            modifier.cancelDiscount();
                            modifier.calcTotal(false);

                            if ((item.supportDiscount() || OrderUtil.supportFullOrderDiscount(discountDBModel, item)) && ingredientList.contains(modifier.menuBiz.uniq)) {
                                total = total.add(modifier.menuBiz.totalPrice);
                            }
                        }
                    }
                }

                if (uniqList.contains(item.menuBiz.uniq)) {
                    if (discountDBModel.ficouponid != 2) {
                        //非整单折扣要判断菜品是否支持此折扣
                        String sql = "select * from (select fsdiscountid from tbDiscountItem where fiItemCd = '" + item.itemID + "' and fiOrderUintCd = '" + item.currentUnit.fiOrderUintCd + "' and fiStatus = '1' union all select fsdiscountid from tbdiscountmenucls where fsMenuClsId = '" + item.categoryCode + "' and fistatus = '1')";
                        List<String> discountIDList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
                        if (!discountIDList.contains(DiscountType.CASH)) {
                            continue;
                        }
                    } else {
                        // 整单打折要判断该折扣是否支持不可折扣菜品参与打折
                        // 不可折扣菜品不参与该整单打折 && 菜品不可折扣 -> 不折
                        if (discountDBModel.fiIsDisMenu == 0 && !item.supportDiscount()) {
                            continue;
                        }
                    }

                    item.cancelDiscount(false);
                    item.calcTotal(item.useMemberPrice);

                    if ((item.supportDiscount() || OrderUtil.supportFullOrderDiscount(discountDBModel, item)) && uniqList.contains(item.menuBiz.uniq)) {
                        total = total.add(item.menuBiz.totalPrice);
                    }
                }
            }

            if (total.compareTo(BigDecimal.ZERO) > 0 && discountAmt != null && discountAmt.compareTo(total) <= 0) {
                disCashRate = discountAmt.divide(total, 4, RoundingMode.HALF_UP);
            }
        }
        return disCashRate;
    }

    private static void cleanMenuCoupon(MenuItem menuItem, Map<String, List<String>> cleanCouponMapping) {
        if (ListUtil.mapIsEmpty(cleanCouponMapping)) {
            return;
        }

        if (cleanCouponMapping.containsKey(menuItem.menuBiz.uniq)) {
            List<String> couponTypeList = cleanCouponMapping.get(menuItem.menuBiz.uniq);
            if (ListUtil.isEmpty(couponTypeList)) {
                return;
            }
            for (String couponType : couponTypeList) {
                cleanMenuCoupon(menuItem, couponType, false);
            }
        }

        if (!ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
            for (MenuItem modifier : menuItem.menuBiz.selectedModifier) {
                if (cleanCouponMapping.containsKey(modifier.menuBiz.uniq)) {
                    List<String> couponTypeList = cleanCouponMapping.get(modifier.menuBiz.uniq);
                    if (ListUtil.isEmpty(couponTypeList)) {
                        return;
                    }
                    for (String couponType : couponTypeList) {
                        cleanMenuCoupon(modifier, couponType, false);
                    }
                }
            }
        }
    }

    private static void cleanMenuCoupon(MenuItem menuItem, String couponType, boolean withIngredient) {
        if (menuItem == null || menuItem.menuBiz == null) {
            return;
        }
        LogUtil.logBusiness(TAG, "清除菜品优惠，couponType=" + couponType + ", menu=[" +
                menuItem.itemID + ", " + menuItem.name + ", " + menuItem.menuBiz.uniq + "]");
        if (TextUtils.equals(couponType, CouponType.GIFT)) { // 赠送
            menuItem.disGift(false);
        } else if (TextUtils.equals(couponType, CouponType.DISCOUNT_NORMAL)) { // 折扣
            menuItem.menuBiz.selectDiscount = null;
        } else if (TextUtils.equals(couponType, CouponType.MEMBER_PRICE)) { // 会员价
            menuItem.useMemberPrice = false;
        } else if (TextUtils.equals(couponType, CouponType.BUY_GIFT)) { // 买减
            menuItem.cleanBuyGiftInfo();
        }

        if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
            for (MenuItem packageItem : menuItem.menuBiz.selectedPackageItems) {
                cleanMenuCoupon(packageItem, couponType, false);
            }
        }

        if (withIngredient && !ListUtil.isEmpty(menuItem.menuBiz.selectedModifier)) {
            for (MenuItem ingredient : menuItem.menuBiz.selectedModifier) {
                cleanMenuCoupon(ingredient, couponType, false);
            }
        }

        menuItem.calcTotal(menuItem.useMemberPrice);
    }
}
