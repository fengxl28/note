package com.mwee.android.pos.businesscenter.air.dbUtil;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.business.print.PrinterItem;
import com.mwee.android.pos.connect.business.print.SunMiV1PrinterInfo;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.DeptDBModel;
import com.mwee.android.pos.db.business.HostDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.posmodel.print.PrinterDBModel;
import com.mwee.android.posmodel.print.PrinterType;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangmin on 2017/10/18.
 */

public class TPrinterUtils {
    public static PrinterDBModel queryByName(String printerName) {
        String sql = "select * from tbPrinter where fiStatus=1 and  fsPrinterName='" + printerName + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
    }

    /**
     * 获取所有相关名称的打印机
     *
     * @param printerName
     * @return
     */
    public static PrinterDBModel queryAllPrinterByName(String printerName) {
        String sql = "select * from tbPrinter where fsPrinterName = '" + printerName + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
    }

    /**
     * 获取所有相关名称的打印机
     *
     * @param printerName
     * @return
     */
    public static PrinterDBModel queryAllActivtPrinterByName(String printerName) {
        String sql = "select * from tbPrinter where fiStatus = '1' AND fsPrinterName = '" + printerName + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
    }

    /**
     * 根据id查询打印机信息
     *
     * @param id
     * @return
     */
    public static PrinterDBModel queryById(int id) {
        String sql = "select * from tbPrinter where fiStatus=1 and fiID='" + id + "'";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, PrinterDBModel.class);
    }

    /**
     * 更新打印部门切单方式
     *
     * @param
     * @param opt
     * @return
     */
    public static synchronized String updateTDeptItemCut(int fiIsOneItemCut, UserDBModel opt) {


        DeptDBModel model = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbDept where fiStatus = '1' and fsDeptId = '2'", DeptDBModel.class);
        if (model == null) {
            return "后厨出菜点普通打印被删除 无法更新打印部门切单方式";
        }
        model.fiIsOneItemCut = fiIsOneItemCut;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        model.fsUpdateUserId = (opt == null ? "" : opt.fsUserId);
        model.fsUpdateUserName = (opt == null ? "" : opt.fsUserName);
        model.sync = 1;
        MetaDBController.updateSyncTime();
        model.replaceNoTrans();
        return "";
    }

    public static List<PrinterDBModel> queryAll() {
        return DBSimpleUtil.queryList(APPConfig.DB_MAIN, "select * from tbPrinter where fiStatus=1", PrinterDBModel.class);
    }

    public static List<PrinterItem> build(String hostId, List<PrinterDBModel> printerDBModels) {
        List<PrinterItem> items = new ArrayList<>();
        if (!ListUtil.isEmpty(printerDBModels)) {
            PrinterItem item = null;
            for (PrinterDBModel printerDBModel : printerDBModels) {
                item = new PrinterItem();
                item.id = printerDBModel.fiID;
                item.type = printerDBModel.fiPrinterCls;
                item.name = printerDBModel.fsPrinterName;
                item.ip = printerDBModel.fsIP;
                item.fsPrinterSN = printerDBModel.fsPrinterSN;
                item.fiPrinterNum = printerDBModel.fiPrinterNum;
                item.fsImageUrl = printerDBModel.fsImageUrl;
                item.isUseHost = HostUtil.isExist(hostId, item.name);
                // 2表示普通部门  3表示标签部门
                item.isUseMake = DeptDBUtils.isExist("2", item.name);
                item.isUseTag = DeptDBUtils.isExist("3", item.name);
                item.size = printerDBModel.fiPaperSize;
                item.fsCommandType = printerDBModel.fsCommandType;
                item.fsStr1 = printerDBModel.fsStr1;
                item.menuClsIds = MenuClsMuldeptDBUtils.queryAllByDeptIds(item.isUseMake, item.isUseTag);
                items.add(item);
            }
        }
        return items;
    }


    /**
     * 新增打印机
     *
     * @param printerItem
     */
    public static void addPrinter(PrinterItem printerItem, String hostId, UserDBModel userDBModel) {
        PrinterDBModel model = new PrinterDBModel();
        if (printerItem.type == PrinterType.BLUETOOTH && SunMiV1PrinterInfo.bluetoothAddress.equals(printerItem.ip)) {
            model.fiID = SunMiV1PrinterInfo.id;
        } else {
            model.fiID = IDHelper.generatePrinterId();
        }
        //搜索的打印机 使用时间戳+usb打印机   添加的打印机使用usb打印机
        model.fsPrinterName = printerItem.name;
        model.fsIP = printerItem.ip;
        model.fsPrinterSN = printerItem.fsPrinterSN;
        model.fiIsMakePrn = 1;
        model.fsCommandType = printerItem.fsCommandType;
        //--打印机接口类型;1网口 / 2串口 / 3并口 / 4=USB口  / 5=KDS  小散项目目前支持网口和USB口
        model.fiPrinterCls = printerItem.type;
        model.fiPrinterNum = printerItem.fiPrinterNum;
        model.fsImageUrl = printerItem.fsImageUrl;
        if (printerItem.type == 9) {//云打印机
            model.fiCPL = 32;
            model.fsStr1 = "";
            model.fsPrinterSN = printerItem.fsPrinterSN;
        } else {
            model.fsStr1 = TextUtils.isEmpty(printerItem.fsStr1) ? "BYUSB-0" : printerItem.fsStr1;
            model.fsIP = printerItem.ip;

        }
        //"BYUSB-0";//--端口值1;  COM1~COM4 / LPT1~LPT4 / BYUSB-0~BYUSB-3
        model.fiInt1 = 0;
        // 0/76mm 1=58mm/ 2=80mm 3/76mm 默认为80mm
        model.fiPaperSize = printerItem.size;
        model.fiTimeOut = 30;
        model.fiRetry = 3;
        model.fiTaskCount = 0;
        model.fiPrinterStatus = 10;
        model.fiStatus = 1;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.fsShopGUID = HostUtil.getShopID();
        model.fsbakprintername = "";
        model.switch_backup = 0;
        model.switchTime = "";
        model.sync = 1;
        model.fiDataSource = 1;
        model.replaceNoTrans();

        if (printerItem.isUseHost) {
            HostUtil.updatePrinterName(hostId, printerItem.name, userDBModel);
        }

        if (printerItem.isUseMake) {
            DeptDBUtils.updateMakeDeptPrinterName(printerItem.name, userDBModel);
        }
        if (printerItem.isUseTag) {
            DeptDBUtils.updateTagDeptPrinterName(printerItem.name, userDBModel);
        }
        MenuClsMuldeptDBUtils.unAssociatePrinter(printerItem.isUseMake ? "2" : "3");
        MenuClsMuldeptDBUtils.associatePrinter(printerItem.menuClsIds, printerItem.isUseMake, printerItem.isUseTag, userDBModel);
        MetaDBController.updateSyncTime();
    }


    public static void updatePrinter(final PrinterItem printerItem, String hostId, final UserDBModel userDBModel) {
        final PrinterDBModel model = queryById(printerItem.id);
        String oldPrinterName = model.fsPrinterName;
        if (model != null) {
            DBManager.getInstance().executeInTransactionWithOutThread(new IDBOperate<Object>() {
                @Override
                public Object doJob(SQLiteDatabase sqLiteDatabase) {
                    ContentValues values = new ContentValues();
                    values.put("fsPrinterName", printerItem.name);
                    values.put("fiPaperSize", printerItem.size);
                    values.put("fiPrinterCls", printerItem.type);
                    values.put("fsCommandType", printerItem.fsCommandType);
                    values.put("fiPrinterNum", printerItem.fiPrinterNum);
                    values.put("fsImageUrl", printerItem.fsImageUrl);
                    if (printerItem.type == 9) {//云打印机
                        values.put("fsPrinterSN", printerItem.fsPrinterSN);
                        values.put("fsStr1", "");
                    } else {
                        values.put("fsIP", printerItem.ip);
                        values.put("fsStr1", TextUtils.isEmpty(printerItem.fsStr1) ? "BYUSB-0" : printerItem.fsStr1);
                    }
                    values.put("fsUpdateTime", DateUtil.getCurrentTime());
                    values.put("sync", 1);
                    if (userDBModel != null) {
                        values.put("fsUpdateUserId", userDBModel.fsUserId);
                        values.put("fsUpdateUserName", userDBModel.fsUserName);
                    }
                    sqLiteDatabase.update("tbPrinter", values, "fiID=?", new String[]{printerItem.id + ""});
                    return null;
                }
            });
            if (HostUtil.isExist(hostId, oldPrinterName)) {
                if (!printerItem.isUseHost) {
                    //之前选中并且当前操作未选中 则将相应站点解除打印机关联
                    HostUtil.updatePrinterName(hostId, "", userDBModel);
                }
            }

            if (DeptDBUtils.isExist("2", oldPrinterName)) {
                if (!printerItem.isUseMake) {
                    DeptDBUtils.updateMakeDeptPrinterName("", userDBModel);
                    MenuClsMuldeptDBUtils.unAssociatePrinter("2");
                }
            }
            if (DeptDBUtils.isExist("3", oldPrinterName)) {
                if (!printerItem.isUseTag) {
                    DeptDBUtils.updateTagDeptPrinterName("", userDBModel);
                    MenuClsMuldeptDBUtils.unAssociatePrinter("3");
                }
            }

            if (printerItem.isUseHost) {
                HostUtil.updatePrinterName(hostId, printerItem.name, userDBModel);
            }

            if (printerItem.isUseMake) {
                DeptDBUtils.updateMakeDeptPrinterName(printerItem.name, userDBModel);
                MenuClsMuldeptDBUtils.unAssociatePrinter("2");
            }
            if (printerItem.isUseTag) {
                DeptDBUtils.updateTagDeptPrinterName(printerItem.name, userDBModel);
                MenuClsMuldeptDBUtils.unAssociatePrinter("3");
            }
            MenuClsMuldeptDBUtils.associatePrinter(printerItem.menuClsIds, printerItem.isUseMake, printerItem.isUseTag, userDBModel);
            MetaDBController.updateSyncTime();
        }
    }

    /**
     * 根据打印机id逻辑删除打印机数据
     *
     * @param id          打印机id
     * @param userDBModel 操作人
     */
    public static void delete(int id, UserDBModel userDBModel) {
        PrinterDBModel model = queryById(id);
        model.fiStatus = 13;
        model.fsUpdateTime = DateUtil.getCurrentTime();
        if (userDBModel != null) {
            model.fsUpdateUserId = userDBModel.fsUserId;
            model.fsUpdateUserName = userDBModel.fsUserName;
        }
        model.sync = 1;
        model.replaceNoTrans();

        if (DeptDBUtils.isExist("2", model.fsPrinterName)) {
            MenuClsMuldeptDBUtils.unAssociatePrinter("2");
            //关联的制作部门置为空
            DeptDBUtils.updateMakeDeptPrinterName("", userDBModel);
        }
        if (DeptDBUtils.isExist("3", model.fsPrinterName)) {
            MenuClsMuldeptDBUtils.unAssociatePrinter("3");
            //关联的标签部门置为空
            DeptDBUtils.updateTagDeptPrinterName("", userDBModel);
        }
        HostDBModel hostDBModel = HostUtil.queryByPrinterName(model.fsPrinterName);
        if (hostDBModel != null && TextUtils.equals(hostDBModel.fsPrinterName, model.fsPrinterName)) {
            //站点置为空
            HostUtil.updatePrinterName(hostDBModel.fsHostId, "", userDBModel);
        }
        MetaDBController.updateSyncTime();
    }

    /**
     * 获取正在使用的打印机列表
     *
     * @return
     */
    public static ArrayList<PrinterItem> queryAllUsePrinter() {
        ArrayList<String> printerNames = new ArrayList<>();
        DeptDBModel make = DeptDBUtils.queryById("2");
        DeptDBModel tag = DeptDBUtils.queryById("3");
        if (make != null) {
            if (!TextUtils.isEmpty(make.fsPrinterName)) {
                //制作部门配置打印机
                printerNames.add(make.fsPrinterName);
            }
        }
        if (tag != null) {

            if (!TextUtils.isEmpty(tag.fsPrinterName) && !printerNames.contains(tag.fsPrinterName)) {
                //标签部门配置打印机  制作部门打印机和标签部门打印机不一致则添加
                printerNames.add(tag.fsPrinterName);
            }
        }
        ArrayList<PrinterItem> printerItems = new ArrayList<>();
        for (String printerName : printerNames) {
            PrinterDBModel model = queryByName(printerName);
            if (model != null) {
                printerItems.add(copyTo(model));
            }
        }
        return printerItems;
    }

    public static PrinterItem copyTo(PrinterDBModel model) {
        PrinterItem item = new PrinterItem();
        item.id = model.fiID;
        item.type = model.fiPrinterCls;
        item.name = model.fsPrinterName;
        return item;
    }
}
