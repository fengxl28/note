package com.mwee.android.pos.businesscenter.print.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.air.db.business.kbbean.bean.PosBillPayChannel;
import com.mwee.android.air.db.business.kbbean.bean.PosDiscountDetail;
import com.mwee.android.pos.businesscenter.air.TicketTempletUtils;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.print.CheckAndPrintUtil;
import com.mwee.android.pos.businesscenter.print.PrintJSONBuilder;
import com.mwee.android.pos.businesscenter.print.PrintReportId;
import com.mwee.android.pos.businesscenter.print.PrintUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MenuItemUnitDBModel;
import com.mwee.android.pos.db.business.ShopDBModel;
import com.mwee.android.pos.db.business.TempAppOrderPrintInfoDBModel;
import com.mwee.android.pos.db.business.common.CommonDBUtil;
import com.mwee.android.pos.db.business.config.DBPrintConfig;
import com.mwee.android.pos.db.business.menu.MenuDBUtil;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.posmodel.print.PrintTaskDBModel;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Description:
 *
 * @author:zhou.junyou Create by:Android Studio
 * Date:2018/5/30
 */
public class KoubeiCustomerPrint extends KoubeiBasePrint {
    String orderId;
    String userName;
    int type;
    String hostId;
    boolean replenishmentReceipt;

    public static final int TYPE_CUSTOMER = 2;
    public static final int TYPE_SHOP = 1;
    public static final int TYPE_MAKE = 0;
    protected KBPreOrderCache orderCache;
    protected List<KBPreMenuItemModel> dishDetails;


    public KoubeiCustomerPrint(int type) {
        this.type = type;
    }

    public KoubeiCustomerPrint() {
        this(TYPE_CUSTOMER);
    }

    public KoubeiCustomerPrint setOrderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public KoubeiCustomerPrint setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    public KoubeiCustomerPrint setReplenishmentReceipt(boolean replenishmentReceipt) {
        this.replenishmentReceipt = replenishmentReceipt;
        return this;
    }

    public KoubeiCustomerPrint setType(int type) {
        this.type = type;
        return this;
    }

    /**
     * 构建打印task
     *
     * @return
     */
    @Override
    public PrintTaskDBModel buildInitPrintTaskModel() {

        //build base taskmodel
        String fsUserName = userName;
        String businessDate = HostUtil.getHistoryBusineeDate("");
        String fsPrinterName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsPrinterName from tbHost where fsHostId = '" + hostId + "'");
        PrintTaskDBModel task = PrintJSONBuilder.buildPrintTask(orderId,
                "",
                businessDate,
                0,
                fsUserName,
                "0",
                PrintReportId.KOBEI_PRE_ORDER_CUSTOMER,
                hostId,
                true
        );
        task.fsPrinterName = fsPrinterName;
        task.uri = "koubei/preOrder";
        return task;
    }

    /**
     * 构建打印数据
     *
     * @return
     */
    @Override
    public com.alibaba.fastjson.JSONObject buildPrintJSONData() {
        orderCache = DBSimpleUtil.query(APPConfig.DB_MAIN,
                "select * from kbOrder where order_id = '" + orderId + "'",
                KBPreOrderCache.class);
        if (orderCache == null) {
            return null;
        }
        String sql = "select order_id from order_cache where thirdOrderId = '" + orderId + "'";
        String mwOrderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
        if (!TextUtils.isEmpty(mwOrderId)) {
            OrderCache mwOrderCache = OrderSession.getInstance().getOrder(mwOrderId);
            if (mwOrderCache != null) {
                /**
                 *
                 * 口碑先付款 分配桌台模式下 兼容
                 * 1 口碑订单先分配桌台不打印  再核销以后打印   【桌台信息能上传到后台 打印单据正确】
                 * 2 口碑订单先进行了核销      再分配桌台后打印 【桌台不能上传到后台  打印单据有误 因为核销以后重新拉取数据  后台桌台名称是下厨时分配 会把本地桌台号覆盖 导致打印有误    为了兼容 需要在打印的时候拦截 去本地桌台名称 】
                 */
                if ("DINNER".equals(orderCache.business_type) && "PLATFORM".equals(orderCache.order_style) && "堂食".equals(orderCache.dinner_type)) {
                    orderCache.take_no = mwOrderCache.fsmtablename;
                }
            }
        }


        hostId = DBMetaUtil.getSettingsValueByKey(META.BIZ_CENTER_CURRENT_HOST_ID);
        dishDetails = JSON.parseArray(orderCache.menuItemListInfo, KBPreMenuItemModel.class);

        for (int i = 0; i < dishDetails.size(); i++) {
            KBPreMenuItemModel kbPreMenuItemModel = dishDetails.get(i);
            MenuItemUnitDBModel unitDBModel = null;
            if (!TextUtils.isEmpty(kbPreMenuItemModel.fiOrderUintCd)) {
                unitDBModel = MenuDBUtil.queryMenuItemUnit(kbPreMenuItemModel.fiOrderUintCd);
            }
            if (unitDBModel == null) { //todo 临时菜的fiOrderUintCd 99995 必须内置数据
                unitDBModel = MenuDBUtil.queryMenuItemUnit("99995");
            }
            kbPreMenuItemModel.dish_unit = unitDBModel.fsOrderUint;
        }

        /**
         * 组打印数据
         */

        com.alibaba.fastjson.JSONObject data = new com.alibaba.fastjson.JSONObject();
        ShopDBModel shopDBModel = DBSimpleUtil.query(APPConfig.DB_MAIN, "select * from tbShop where fsShopGuid=(select value from meta where key='" + META.SHOPID + "')", ShopDBModel.class);
        data.put("Shop", shopDBModel);


        com.alibaba.fastjson.JSONObject orderCacheObject = new com.alibaba.fastjson.JSONObject();
        data.put("KBPreOrderCache", orderCacheObject);
        orderCacheObject.put("order_id", orderCache.order_id);
        orderCacheObject.put("mwOrderId", mwOrderId);
        orderCacheObject.put("dinner_type", orderCache.dinner_type);
        orderCacheObject.put("people_num", orderCache.people_num);
        orderCacheObject.put("take_no", orderCache.take_no);
        orderCacheObject.put("order_time", orderCache.order_time);
//        orderCacheObject.put("order_style",orderCache.order_style);// add by zl 判断扫码还是
        if (!orderCache.order_style.equals("SCAN")) {
            //去掉秒
            if (orderCache.table_time != null && orderCache.table_time.length() > 3) {
                String table_time = orderCache.table_time.substring(0, orderCache.table_time.length() - 3);
                orderCacheObject.put("table_time", table_time);
            }
        }
        orderCacheObject.put("user_mobile", orderCache.user_mobile);
        orderCacheObject.put("memo", orderCache.memo);
        orderCacheObject.put("service_amount", orderCache.service_amount);
        orderCacheObject.put("packing_amount", orderCache.packing_amount);
        orderCacheObject.put("other_amount", orderCache.other_amount);
        orderCacheObject.put("bill_amount", orderCache.bill_amount);
        orderCacheObject.put("receipt_amount", orderCache.receipt_amount);
        orderCacheObject.put("discount_amount", orderCache.bill_amount.subtract(orderCache.receipt_amount));


        //dish items
        JSONArray dishDetailArray = new JSONArray();
        data.put("dish_details", dishDetailArray);
        for (int i = 0; i < dishDetails.size(); i++) {
            com.alibaba.fastjson.JSONObject dishDetailObject = new com.alibaba.fastjson.JSONObject();
            KBPreMenuItemModel kbPreMenuItemModel = dishDetails.get(i);
            if (TextUtils.equals(kbPreMenuItemModel.dish_name, "预点单餐盒费")) {
                continue;
            }
            dishDetailArray.add(dishDetailObject);
            dishDetailObject.put("dish_name", kbPreMenuItemModel.dish_name);
            dishDetailObject.put("sell_price", kbPreMenuItemModel.sell_price);
            dishDetailObject.put("dish_num", kbPreMenuItemModel.dish_num);
            BigDecimal dishTotalPrice = kbPreMenuItemModel.sell_price.multiply(kbPreMenuItemModel.dish_num);
            dishDetailObject.put("dish_total_amount", dishTotalPrice);
            dishDetailObject.put("dish_unit", kbPreMenuItemModel.dish_unit);
            dishDetailObject.put("memo", kbPreMenuItemModel.memo);
            dishDetailObject.put("practice_info", kbPreMenuItemModel.practice_info);
            dishDetailObject.put("parentName", kbPreMenuItemModel.parentName);

            //当前菜品是套餐
            JSONArray dishDetailArrayPackage = new JSONArray();
            if (kbPreMenuItemModel.main_flag && kbPreMenuItemModel.type.equals("COMBO")) {
                for (KBPreMenuItemModel item : kbPreMenuItemModel.packageMenuItemDetails) {
                    com.alibaba.fastjson.JSONObject itemPackage = new com.alibaba.fastjson.JSONObject();
                    itemPackage.put("dish_name", item.dish_name);
                    itemPackage.put("sell_price", item.sell_price);
                    itemPackage.put("dish_num", item.dish_num);
                    itemPackage.put("dish_total_amount", item.sell_price.multiply(item.dish_num));
                    itemPackage.put("dish_unit", item.dish_unit);
                    itemPackage.put("memo", item.memo);
                    itemPackage.put("practice_info", item.practice_info);
                    dishDetailObject.put("parentName", item.parentName);
                    dishDetailArrayPackage.add(itemPackage);
                }
            }
            dishDetailObject.put("SLIT", dishDetailArrayPackage);

            //处理配料菜
            //dishDetailObject.put("ingredientNotes", kbPreMenuItemModel.ingredientNotes);
            dishDetailObject.put("selectedModifier", kbPreMenuItemModel.selectedModifier);
        }


        //打印美味广告
        PrintUtil.printMWAD(data);
        data.put("hostName", hostId);
        JSONArray statisticsDiscountArray = new JSONArray();
        JSONArray payChannelsArray = new JSONArray();
        List<PosBillPayChannel> posBillPayChannels = JSON.parseArray(orderCache.payListInfo, PosBillPayChannel.class);
        if (posBillPayChannels != null) {
            for (PosBillPayChannel posBillPayChannel : posBillPayChannels) {
                List<RapidPayModel> rapidPayModels = posBillPayChannel.rapidPayModels;
                if (rapidPayModels != null) {
                    for (RapidPayModel rapidPayModel : rapidPayModels) {
                        JSONObject rapidObject = new JSONObject();
                        if (TextUtils.equals(rapidPayModel.fsPaymentName, "支付宝口碑支付") || TextUtils.equals(rapidPayModel.fsPaymentName, "微信小程序口碑支付")) {
                            rapidObject.put("channel_type", rapidPayModel.fsPaymentName);
                            rapidObject.put("pay_amount", rapidPayModel.fdReceMoney);
                            payChannelsArray.add(rapidObject);
                        }
                    }
                }

                List<PosDiscountDetail> discount_details = posBillPayChannel.discount_details;
                if (discount_details != null) {
                    for (PosDiscountDetail discountDetail : discount_details) {
                        JSONObject disCountDetailObject = new JSONObject();
                        disCountDetailObject.put("fsDiscountName", discountDetail.discount_name);
                        disCountDetailObject.put("discountamt", discountDetail.mrt_discount.add(discountDetail.rt_discount));
                        statisticsDiscountArray.add(disCountDetailObject);
                    }
                }
            }


        }

        if (!statisticsDiscountArray.isEmpty()) {
            data.put("statisticsDiscount", statisticsDiscountArray);
        }
        if (!payChannelsArray.isEmpty()) {
            data.put("pay_channels", payChannelsArray);
        }


        String beep = CommonDBUtil.getConfig(DBPrintConfig.PRINT_WITH_BBEEP);
        data.put("beep", beep);
        return data;
    }

    /**
     * 打印 1构建数据 2构建task 3打印
     */
    @Override
    public void print() {
        synchronized (ServerCache.getInstance().netOrderCache.optLock(String.valueOf(orderId))) {
            if (!interruptPrint()) {
                JSONObject data = buildPrintJSONData();
                if (data == null) {
                    return;
                }
                PrintTaskDBModel originalTask = buildInitPrintTaskModel();
                List<PrintTaskDBModel> multiplyTasks = onBuildTasks(data, originalTask);
                if (multiplyTasks == null || multiplyTasks.isEmpty()) {
                    return;
                }
                for (PrintTaskDBModel task : multiplyTasks) {
                    CheckAndPrintUtil.buildTaskEnvAndPrint(task);
                }
                updateTempAppOrderPrintInfo(orderId, type, replenishmentReceipt);
            }
        }
    }

    /**
     * 中断打印条件
     *
     * @return
     */
    @Override
    protected boolean interruptPrint() {
        boolean interruptPrint = checkTempAppOrderPrintInfo(String.valueOf(orderId), type) && replenishmentReceipt;
        if (interruptPrint) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-客户联小票 中断，理由：已打印过" + JSON.toJSONString(orderId), orderId + "");
        }
        return interruptPrint;
    }


    /**
     * 用于data 构建task  有的需要构建多个task 比如多部门打印
     *
     * @param data 打印数据
     * @param task 打印 任务
     * @return
     */
    @Override
    protected List<PrintTaskDBModel> onBuildTasks(JSONObject data, PrintTaskDBModel task) {
        ArrayList<PrintTaskDBModel> printTaskDBModels = new ArrayList<>();
        data.put("titleSubFix", "-客户联");
//        if(data.containsKey("KBPreOrderCache")){
//            JSONObject cacheObj = data.getJSONObject("KBPreOrderCache");
//            //订单来源是扫码
//            if(cacheObj.get("order_style").toString().equals("SCAN") && cacheObj.containsKey("table_time")){
//                cacheObj.remove("table_time");
//            }
//        }
        //打印号
        int printNO = PrintJSONBuilder.generatePrintNO();
        data.put("fiPrintNo", printNO);
        task.fiPrintNo = printNO;
        task.uri = TicketTempletUtils.getKBOrderCustomUri();
        task.fsPrnData = data.toJSONString();
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单-打印-客户联task" + JSON.toJSONString(task), "");
        printTaskDBModels.add(task);
        return printTaskDBModels;
    }


    ///////////////////////////////////////////////////////////////////////////
    // 复制PrintNetOrderUtil 方法
    ///////////////////////////////////////////////////////////////////////////

    /**
     * 判断小票是否打印过
     *
     * @param orderId
     * @param receptType 小票类型0：制作单；1：结账单
     * @return boolean | true : 打印过； false : 未打印过
     */
    protected static boolean checkTempAppOrderPrintInfo(String orderId, int receptType) {
        String sql = "select guid from TempAppOrderPrintInfo where orderId = '" + orderId + "' and receptType = '" + receptType + "'";
        return !TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_NET_ORDER, sql));
    }


    /**
     * 新增打印记录
     *
     * @param receptType           小票类型0：制作单；1：结账单
     * @param replenishmentReceipt 是否补单； 0：POS正常接单打印；1：补单；
     */
    protected static void updateTempAppOrderPrintInfo(String orderId, int receptType, boolean replenishmentReceipt) {
        String sql = "select * from TempAppOrderPrintInfo where orderId = '" + orderId
                + "' and receptType = '" + receptType
                + "' and printType = '" + (replenishmentReceipt ? "1" : "0") + "'";
        TempAppOrderPrintInfoDBModel tempAppOrderPrintInfoDBModel = DBSimpleUtil.query(APPConfig.DB_NET_ORDER, sql, TempAppOrderPrintInfoDBModel.class);
        if (tempAppOrderPrintInfoDBModel == null) {
            tempAppOrderPrintInfoDBModel = new TempAppOrderPrintInfoDBModel();
            tempAppOrderPrintInfoDBModel.guid = UUIDUtil.optUUID();
            tempAppOrderPrintInfoDBModel.orderId = String.valueOf(orderId);
            tempAppOrderPrintInfoDBModel.printTime = DateUtil.getCurrentTime();
            tempAppOrderPrintInfoDBModel.printTyp = replenishmentReceipt ? 1 : 0;
            tempAppOrderPrintInfoDBModel.receptType = receptType;
            tempAppOrderPrintInfoDBModel.fsShopGUID = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select value from meta where key='104'");
            tempAppOrderPrintInfoDBModel.setDbName(APPConfig.DB_NET_ORDER);
            tempAppOrderPrintInfoDBModel.replaceNoTrans();
        }
    }
}
