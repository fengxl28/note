package com.mwee.android.pos.businesscenter.dbutil;

import android.text.TextUtils;

import com.mwee.android.pos.businesscenter.business.einvoice.EInvoiceProcess;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.ManualInvoicingDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.Calc;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.StringUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class ManualIEnvoiceDBUtil {

    /**
     * 查询发票
     *
     * @param date 自然日
     * @return
     */
    public static List<ManualInvoicingDBModel> optManualInvoicingDBModeList(int pageIndex, int messageConuntOnePage, String date) {
        if (messageConuntOnePage <= 0) {
            messageConuntOnePage = 10;
        }
        pageIndex = pageIndex - 1;
        if (pageIndex < 0) {
            pageIndex = 0;
        }
        String paramSql = "";
        if (!TextUtils.isEmpty(date)) {
            paramSql = " date = '" + date + "' ";
        }
        String sql = "select * from manualInvoicing  where " + paramSql + " order by createTime desc limit " + (pageIndex * messageConuntOnePage) + "," + messageConuntOnePage;
        List<ManualInvoicingDBModel> manualInvoicingDBModels = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, ManualInvoicingDBModel.class);
        if (manualInvoicingDBModels == null || manualInvoicingDBModels.isEmpty()) {
            manualInvoicingDBModels = new ArrayList<>();
        }

        return manualInvoicingDBModels;
    }

    /**
     * 查询发票
     *
     * @param status int | <= -100 表示不需要过滤状态; 0:未开票； 10：开票中； 20：开票成功； 30开票失败
     * @param date   String | 自然日
     * @return
     */
    public static int optCount(int status, String date) {
        String sql = "";

        if (TextUtils.isEmpty(date) && status <= -100) {
            sql = "select count(*) count from manualInvoicing  ";
        } else if (!TextUtils.isEmpty(date) && status > -100) {
            sql = "select count(*) count from manualInvoicing where status = '" + status + "' and date = '" + date + "' ";
        } else if (TextUtils.isEmpty(date)) {
            sql = "select count(*) count from manualInvoicing where status = '" + status + "' ";
        } else {
            sql = "select count(*) count from manualInvoicing where date = '" + date + "' ";
        }

        String count = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);

        return StringUtil.toInt(count, 0);
    }


    /**
     * 查询发票
     *
     * @param amt 金额
     * @return
     */
    public static ManualInvoicingDBModel addManualInvoicing(BigDecimal amt, UserDBModel userDBModel) {
        if (amt == null) {
            amt = BigDecimal.ZERO;
        }
        amt = Calc.format(amt, 2, RoundingMode.HALF_UP);
        ManualInvoicingDBModel manualInvoicingDBModel = new ManualInvoicingDBModel();
        manualInvoicingDBModel.orderId = "M" + ServerCache.getInstance().shopID + DateUtil.getCurrentDate(DateUtil.DATE_YYYYMMDDHHMMSSSSS);
        manualInvoicingDBModel.fsShopGUID = ServerCache.getInstance().shopID;
        manualInvoicingDBModel.createTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        manualInvoicingDBModel.code = EInvoiceProcess.optEInvoiceQR(manualInvoicingDBModel.orderId, amt, manualInvoicingDBModel.createTime);
        manualInvoicingDBModel.amt = amt;
        manualInvoicingDBModel.printTimes = 0;
        manualInvoicingDBModel.status = 0;
        manualInvoicingDBModel.date = DateUtil.getCurrentDate("yyyy-MM-dd");
        manualInvoicingDBModel.updateTime = DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT);
        if (userDBModel != null) {
            manualInvoicingDBModel.updateUserId = userDBModel.fsUserId;
            manualInvoicingDBModel.updateUserName = userDBModel.fsUserName;
        }
        manualInvoicingDBModel.replaceNoTrans();
        return manualInvoicingDBModel;
    }

    /**
     * 获取小票对象
     *
     * @param orderId
     * @return
     */
    public static ManualInvoicingDBModel optManualInvoicingDBModeById(String orderId) {

        String sql = "select * from manualInvoicing  where orderId='" + orderId + "' ";
        return DBSimpleUtil.query(APPConfig.DB_MAIN, sql, ManualInvoicingDBModel.class);
    }


    /**
     * 更新开票状态
     *
     * @param orderId 小票ID
     * @param status  状态 | 0:未开票； 10：开票中； 20：开票成功； 30开票失败
     * @param note
     */
    public static void updateStatus(String orderId, int status, String note) {
        String sql = "update manualInvoicing set status = '" + status + "' where orderId='" + orderId + "' ";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

    /**
     * 更新开票次数
     *
     * @param orderId  小票ID
     * @param times    次数
     * @param userId
     * @param userName
     */
    public static void updatePrintTimes(String orderId, int times, String userId, String userName) {
        String sql = "update manualInvoicing " +
                "set printTimes = '" + times + "' ,updateUserId = '" + userId + "', updateUserName= '" + userName + "',updateTime = '" + DateUtil.getCurrentDate(DateUtil.DATE_VISUAL14FORMAT) + "' " +
                " where orderId='" + orderId + "' ";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, sql);
    }

}
