package com.mwee.android.pos.businesscenter.driver;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.mwee.android.air.db.business.kbbean.bean.KBAfterPayBean;
import com.mwee.android.base.task.ASyncExecute;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.drivenbus.IDriver;
import com.mwee.android.drivenbus.component.DrivenMethod;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidGetModel;
import com.mwee.android.pos.business.rapid.api.bean.model.RapidPayModel;
import com.mwee.android.pos.businesscenter.business.koubei.KBAfterPayProcessor;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidActionModel;
import com.mwee.android.pos.businesscenter.business.rapid.api.RapidResult;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.PayCache;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.config.SocketResultCode;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.connect.framework.SocketResponse;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.MSectionDBModel;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSaveDBUtil;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.order.OrderStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PayOriginModel;
import com.mwee.android.pos.db.business.pay.PaySaveDBUtil;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.report.model.ReportDailySellOrderItem;
import com.mwee.android.pos.util.DbUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.pos.util.ToastUtil;
import com.mwee.android.pos.util.UUIDUtil;
import com.mwee.android.sqlite.base.DBManager;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.sqlite.base.DBToolsUtil;
import com.mwee.android.sqlite.base.IDBOperate;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 开发测试用Drive
 */
@SuppressWarnings("unused")
public class DevelopDriver implements IDriver {

    private static final String TAG = "developDriver";

    @DrivenMethod(uri = TAG + "/koubeiAfterPay")
    public SocketResponse loadMemberConfig(SocketHeader header, String param) {

        SocketResponse response = new SocketResponse();

        try {
            RapidGetModel data = optRapidGetModel();

            if (TextUtils.isEmpty(data.fstdata)) {
                KBAfterPayBean kbData = optDate();
                data.fstdata = JSON.toJSONString(kbData);
            }
            RapidActionModel resultData = new RapidActionModel();
            resultData.fsid = data.fsid;
            resultData.result = RapidResult.SUCCESS;
            KBAfterPayProcessor.afterPayNotify(resultData, data);
        } catch (Exception e) {
            LogUtil.logError(e);
            response.code = SocketResultCode.EXCEPTION;
        }
        return response;
    }

    /**
     * 模拟口碑后付数据
     * <p>
     * "seller_amount": "0.01",
     * "platform_discount_amount": "0.00",
     * "mdiscount_amount": "0.00",
     * "online_payment_no": "2018110522001434025429753589",
     * "buyer_amount": "0.01",
     * "out_biz_no": "20180908194213",
     * "koubeiYudianEnable": "0",
     * "discount_infos": "[]",
     * "mwShopId": 215632,
     * "pay_time": "2018-11-05 19:42:30",
     * "shop_id": "2018091900077000000062903486",
     * "order_discount_amount": "9.99",
     * "partner_id": "2088502188987200",
     * "cancel_timeout": "2018-11-06 19:42:30",
     * "order_digest": "{"receivable_amount":"0.00","total_adjust_amount":"0.00","total_amount":"10.00","total_discount_amount":"9.99","total_paymented_amount":"0.01"}",
     * "payment_id": "20181105111040031700860603563529",
     * "payable_amount": "0.01",
     * "order_id": "20181105111040032200860600311028",
     *
     * @return
     */
    private static KBAfterPayBean optDate() {
        KBAfterPayBean kbData = new KBAfterPayBean();
        kbData.seller_amount = new BigDecimal("10");
        kbData.platform_discount_amount = new BigDecimal("0");
        kbData.mdiscount_amount = new BigDecimal("0");
        kbData.buyer_amount = new BigDecimal("0.01");
        kbData.payable_amount = new BigDecimal("10");
        kbData.order_discount_amount = new BigDecimal("0");
        kbData.online_payment_no = "2018110522001434025429753589";
        kbData.out_biz_no = "201809180029";
        kbData.koubeiYudianEnable = "0";
        kbData.mwShopId = "134299";
        kbData.pay_time = "2018-11-05 19:42:30";
        kbData.cancel_timeout = "2018-11-05 19:42:30";
        kbData.shop_id = "2018091900077000000062903486";
        kbData.partner_id = "2088502188987200";
        kbData.payment_id = "20181105111040031700860603563529";
        kbData.order_id = "20181105111040032200860600311028";
        kbData.payment_method = "ALIPAY";
        kbData.rapidPayModels.addAll(optRapidPayModels());
        return kbData;
    }


    private static RapidGetModel optRapidGetModel() {
        RapidGetModel rapidGetModel = new RapidGetModel();
        rapidGetModel.fsid = "a84d16d7-b7f7-4b03-bccb-5652d6619a39";
        return rapidGetModel;
    }

    /**
     * 模拟口碑后付支付信息
     *
     * @return
     */
    private static List<RapidPayModel> optRapidPayModels() {
        List<RapidPayModel> rapidPayModels = new ArrayList<>();
        RapidPayModel rapidPayModel1 = new RapidPayModel();
        rapidPayModel1.fdReceMoney = new BigDecimal("0.01");
        rapidPayModel1.fiPaymentType = "123";
        rapidPayModel1.fsPaymentId = "sys18003";
        rapidPayModel1.fsPaymentName = "支付宝口碑支付";
        rapidPayModel1.fsShopGUID = 134299;
        rapidPayModels.add(rapidPayModel1);

        RapidPayModel rapidPayModel2 = new RapidPayModel();
        rapidPayModel2.fdReceMoney = new BigDecimal("0");
        rapidPayModel2.fiPaymentType = "90";
        rapidPayModel2.fsPaymentId = "99002";
        rapidPayModel2.fsPaymentName = "支付宝商家补贴金额";
        rapidPayModel2.fsShopGUID = 134299;
        rapidPayModels.add(rapidPayModel2);

        RapidPayModel rapidPayModel3 = new RapidPayModel();
        rapidPayModel3.fdReceMoney = new BigDecimal("9.99");
        rapidPayModel3.fiPaymentType = "40";
        rapidPayModel3.fsPaymentId = "94002";
        rapidPayModel3.fsPaymentName = "支付宝平台优惠";
        rapidPayModel3.fsShopGUID = 134299;
        rapidPayModels.add(rapidPayModel3);

        return rapidPayModels;
    }


    @DrivenMethod(uri = TAG + "/autoOrder")
    public SocketResponse autoOrder(SocketHeader header, String param) {

        SocketResponse response = new SocketResponse();

        JSONObject request = JSON.parseObject(param);
        int orderCount = request.getInteger("orderCount");
        int menuCount = request.getInteger("menuCount");

        try {
            BusinessExecutor.executeNoWait(() -> {
                autoOrder(orderCount,menuCount);
                return null;
            });
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
            response.message = e.getMessage();
        }
        return response;
    }

    private static void autoOrder(int orderCount,int menuCount){
        long startTime = System.currentTimeMillis();
        LogUtil.log(TAG,"自动下单开始(订单数量:"+orderCount+",菜品数量:"+menuCount+")");
        MenuItem menuItem = getOrderMenuFormDB();
        if(menuItem == null){
            throw new IllegalArgumentException("请先手动下一单，自动下单会从此单中取一个菜品");
        }
        for (int i = 0; i < orderCount; i++) {

            //1 生成Ordercache
            OrderCache orderCache = optOrderCache();

            //2 插入菜品
            for (int y = 0; y < menuCount; y++) {
                MenuItem tempMenu = menuItem.clone();
                tempMenu.updateOrderSeq(1);
                tempMenu.menuBiz.uniq = UUIDUtil.optUUID();
                orderCache.originMenuList.add(tempMenu);
            }
            orderCache.reCalcAllByAll();

            //3 生成PaySession对象
            String billNO = OrderDriver.generateNewID(ServerCache.getInstance().shopID, OrderDriver.KEY_BILL);
            PaySession paySession = OrderUtil.buildPayCache(null, orderCache, billNO, HostBiz.cloudsite, "cash", "auto");

            //4 插入具体支付方式
            PayModel currentSelectPay = new PayModel();
            currentSelectPay.data  = PayCache.getInstance().payTypeList.get(0);
            currentSelectPay.payAmount = paySession.priceLeftToPay;
            currentSelectPay.waiterID = "cash";
            currentSelectPay.waiterName = "auto";
            currentSelectPay.hostID = HostBiz.cloudsite;
            currentSelectPay.seq = 1;
            paySession.selectPayListFull.add(currentSelectPay);

            //5、更改订单状态、支付状态
            orderCache.orderStatus = OrderStatus.PAIED;
            paySession.payed = 1;
            paySession.locked = 1;
            paySession.waiterID = "cash";
            paySession.waiterName = "auto";
            paySession.currentShiftID = "2";
            paySession.payTime = DateUtil.getCurrentDateTime(DateUtil.DATE_VISUAL14FORMAT);

            //6、插入数据库
            saveOrderCache(orderCache.orderID, orderCache);
            OrderProcessor.saveOrder(orderCache, null);

            PaySaveDBUtil.save(orderCache.orderID, paySession);
            OrderProcessor.savePayOnly(paySession);

            SystemClock.sleep(200);
            LogUtil.log(TAG,"自动下单中(当前第:"+(i+1)+"单,orderID:"+orderCache.orderID+")");
        }
        LogUtil.log(TAG,"自动下单结束(订单数量:"+orderCount+",总耗时:"+(System.currentTimeMillis()-startTime)+")");
    }

    private static void saveOrderCache(final String orderID, final OrderCache cache){
        LogUtil.log("OrderSave " + orderID);
        IDBOperate op = db -> {
            List<MenuItem> list = cache.originMenuList;

            ContentValues contentValues = new ContentValues();
            contentValues.put("order_id", orderID);
            OrderSaveDBUtil.saveMenu(db, orderID, list);
            cache.originMenuList = null;
            contentValues.put("value", JSON.toJSONString(cache, SerializerFeature.DisableCircularReferenceDetect));
            contentValues.put("order_status", cache.orderStatus);
            contentValues.put("total_price", cache.optTotalPrice().toPlainString());
            contentValues.put("person_num", cache.personNum);
            contentValues.put("create_time", cache.createTime);
            contentValues.put("tableID", cache.fsmtableid);
            contentValues.put("tableName", cache.fsmtablename);
            contentValues.put("business_date", cache.businessDate);
            contentValues.put("mealNumber", cache.mealNumber);
            contentValues.put("is_member", cache.isMember ? 1 : 0);
            contentValues.put("fiSellType", cache.fiSellType);
            contentValues.put("rewardinfo", cache.rewardinfo);
            contentValues.put("fsBillSourceId", cache.fsBillSourceId);
            contentValues.put("antiPayCount", cache.antiPayCount);
            contentValues.put("printPre", cache.printPre);
            contentValues.put("thirdOrderId", cache.thirdOrderId);
            contentValues.put("member_info", cache.memberInfoS != null ? JSON.toJSONString(cache.memberInfoS) : "");
            contentValues.put("hidden", cache.hidden);
            contentValues.put("invoiceState", cache.invoiceState);
            contentValues.put("invoiceDetail", cache.invoiceDetailBean != null ? JSON.toJSONString(cache.invoiceDetailBean) : "");
            cache.originMenuList = list;
            db.replace("order_cache", null, contentValues);
            return null;
        };
        DBManager.getInstance().executeInTransactionWithOutThread(op);
    }

    /**
     * 获取订单的菜品
     *
     * @return List<MenuItem>
     */
    public static MenuItem getOrderMenuFormDB() {
        JSONObject jsonObject = DBSimpleUtil.queryJson(APPConfig.DB_MAIN, "select * from order_menu_cache limit 1");
       return OrderSaveDBUtil.buildMenuByJson(jsonObject);
    }


    private static OrderCache optOrderCache() {
        OrderCache orderCache = OrderDriver.generateNewOrder();
        String orderId = orderCache.orderID;
        String newId = orderId.substring(8);

        orderCache.fsmareaid = "4";
        orderCache.areaName = "美味体验优雅美丽大方区";
        orderCache.fsmtableid = "17";
        orderCache.fsmtablename = "Apple";

        orderCache.personNum = 4;
        orderCache.createTime = DateUtil.getCurrentDateTime("HH:mm:ss");
        orderCache.waiterID = "cash";
        orderCache.waiterName = "auto";
        orderCache.shopID = ServerCache.getInstance().shopID;
        orderCache.currentHostID = HostBiz.cloudsite;
        orderCache.currentSectionID = optCurrentSectionID();
        orderCache.businessDate = optBusinessDate();
        orderCache.orderID = orderId;
        orderCache.mealNumber = newId + "";
        orderCache.orderStatus = OrderStatus.NORMAL;

        int currentSeq = orderCache.currentSeq;
        UserDBModel userDBModel = new UserDBModel();
        userDBModel.fsUserId = "cash";
        userDBModel.fsUserName = "auto";
        orderCache.updateSeqStatus(currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);

        return orderCache;
    }
    private static String currentSectionID;
    private static String optCurrentSectionID(){
        if(TextUtils.isEmpty(currentSectionID)){
            currentSectionID = OrderUtil.getSectionId();
        }
        return currentSectionID;
    }

    private static String businessDate;
    private static String optBusinessDate(){
        if(TextUtils.isEmpty(businessDate)){
            businessDate = HostUtil.getHistoryBusineeDate("");
        }
        return businessDate;
    }

    @DrivenMethod(uri = TAG + "/testSqlCostTime")
    public SocketResponse testSqlCostTime(SocketHeader header, String param) {

        SocketResponse response = new SocketResponse();

        try {
            JSONObject request = JSON.parseObject(param);
            String sql = request.getString("sql");
            long time = System.currentTimeMillis();

            Cursor cursor = DbUtil.query(APPConfig.DB_MAIN,sql);
            while (cursor.moveToNext()){
            }
            cursor.close();
            response.message = (System.currentTimeMillis()-time)+"";
        } catch (Exception e) {
            response.code = SocketResultCode.BUSINESS_FAILED;
        }
        return response;
    }

    @Override
    public String getModuleName() {
        return TAG;
    }
}
