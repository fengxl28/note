package com.mwee.android.pos.businesscenter.business.koubei;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mwee.android.air.db.business.kbbean.bean.KBPartRefundExtInfo;
import com.mwee.android.air.db.business.kbbean.bean.PosBillPayChannel;
import com.mwee.android.air.db.business.kbbean.bean.RefundAction;
import com.mwee.android.air.db.business.kbbean.bean.KBPreMenuItemModel;
import com.mwee.android.air.db.business.kbbean.bean.KBPreOrderCache;
import com.mwee.android.pos.businesscenter.module.koubei.process.KBOrderUtils;
import com.mwee.android.pos.businesscenter.business.localpush.NotifyToClient;
import com.mwee.android.pos.businesscenter.business.pay.PayProcessor;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodBusinessUtil;
import com.mwee.android.pos.businesscenter.dbutil.FastFoodDBUtil;
import com.mwee.android.pos.businesscenter.dbutil.TableDBUtil;
import com.mwee.android.pos.businesscenter.driver.BillUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.businesscenter.framework.UserCache;
import com.mwee.android.pos.client.db.ClientMetaUtil;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.connect.framework.SocketHeader;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBConstants;
import com.mwee.android.pos.db.HostBiz;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.UserDBModel;
import com.mwee.android.pos.db.business.menu.OrderUtil;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.OrderSeqStatus;
import com.mwee.android.pos.db.business.pay.PayModel;
import com.mwee.android.pos.db.business.pay.PaySession;
import com.mwee.android.pos.db.business.pay.PayType;
import com.mwee.android.pos.db.business.pay.PayTypeStatus;
import com.mwee.android.pos.util.DateTimeUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.DateUtil;
import com.mwee.android.tools.LogUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Created by zhangmin on 2018/5/17.
 */

public class KBPreOrderDBUtils {

    /**
     * 根据order_id 判断订单是否存在
     *
     * @param order_id
     * @return
     */
    public static boolean isExist(String order_id) {

        String id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select order_id from kbOrder where order_id = '" + order_id + "'");
        if (TextUtils.isEmpty(id)) {
            return false;
        }
        return true;
    }


    /**
     * 判断是否开启了口碑预点单自动接单功能
     * (默认自动接单)
     *
     * @return
     */
    public static boolean isAutoAccept() {

        //return TextUtils.equals(ClientMetaUtil.getConfig(META.TAKE_ORDER_MANUALLY, "1"), "2");
        return TextUtils.equals(ClientMetaUtil.getConfig(META.TAKE_ORDER_MANUALLY, "2"), "2");
    }


    /**
     * 是否是桌台模式
     * <p>
     * 业务类型：DINNER-正餐、SNACK-快餐
     *
     * @return true 桌台模式  false 快餐模式
     */
    public static boolean isTableDinner(String business_type) {
        return TextUtils.equals("DINNER", business_type);
    }


    /**
     * 前提桌台模式下 是否是堂食
     * FOR_HERE("FOR_HERE", "堂食"),
     * <p>
     * TAKE_OUT("TAKE_OUT", "外卖"),
     * TO_GO("TO_GO", "外带"),
     *
     * @param dinner_type
     * @return true 堂食   false 外卖/外带
     */
    public static boolean isTableForHere(String dinner_type) {
        return TextUtils.equals("堂食", dinner_type);

    }

    /**
     * 插入数据
     *
     * @param orderCache
     * @param corver     获取订单详情的时候 因为后台推过来的菜 fiItemCD 和 fiOrderUintCd 在本地不一定存在 不可能在客户端校验 这时候需要自己特别处理 否则前台显示不准确
     *                   <p>
     *                   true/需要中转  false不需要中转
     */
    public static void insert(KBPreOrderCache orderCache, boolean corver) {
        if (corver) {
            //TODO 数据需要中转 因为后台推过来的菜 fiItemCD 和 fiOrderUintCd 在本地不一定存在 不可能在客户端校验 这时候需要自己特别处理 否则前台显示不准确
            for (KBPreMenuItemModel dish_detail : orderCache.dish_details) {
                if (TextUtils.isEmpty(dish_detail.fiItemCd) || TextUtils.isEmpty(dish_detail.fiOrderUintCd)) {
                    continue;
                }
                String sqlMenuItem = "select fsItemName from tbmenuitem where fiItemCd='" + dish_detail.fiItemCd + "' and fistatus = '1'";
                String fsItemName = DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMenuItem);
                if (TextUtils.isEmpty(fsItemName)) {//菜品
                    RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, String.format("获取订单详情 [%s]菜品与本地数据匹配不上 直接设置返回数据fiItemCd=null 防止界面显示错误 ", dish_detail.dish_name)
                            , String.format("口碑订单号[%s] 口碑菜品fiItemCd[%s]", orderCache.order_id, dish_detail.fiItemCd));
                    dish_detail.fiItemCd = null;
                    continue;
                }
                String sqlMenuItemUint = "SELECT fiOrderUintCd from tbmenuitemuint where fiOrderUintCd= '" + dish_detail.fiOrderUintCd + "' and fistatus ='1'";
                if (TextUtils.isEmpty(DBSimpleUtil.queryString(APPConfig.DB_MAIN, sqlMenuItemUint))) {//规格

                    RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, String.format("获取订单详情 [%s]菜品的规格与本地数据匹配不上 直接设置返回数据fiOrderUintCd=null 防止界面显示错误", dish_detail.dish_name)
                            , String.format("口碑订单号[%s] 口碑菜品规格fiOrderUintCd[%s]", orderCache.order_id, dish_detail.fiOrderUintCd));
                    dish_detail.fiOrderUintCd = null;
                    continue;
                }
            }
        }
        List<KBPreMenuItemModel> itemModels = transpMenuitem(orderCache);
        orderCache.dish_details = itemModels;
        orderCache.menuItemListInfo = JSON.toJSONString(itemModels);
        orderCache.payListInfo = JSON.toJSONString(orderCache.pay_channels);
        orderCache.replaceNoTrans();
    }

    /**
     * 处理中转
     */
    private static synchronized List<KBPreMenuItemModel> transpMenuitem(KBPreOrderCache orderCache) {
        //套餐头
        List<KBPreMenuItemModel> packageHeaderLists = new ArrayList<>();
        /**
         * 套餐明细 key-->fiItemCd   value-->List<KBPreMenuItemModel>
         *     归属于套餐头里面去 从列表移除
         */
        HashMap<String, ArrayList<KBPreMenuItemModel>> packageDetailsMap = new HashMap<>();
        /**
         *  菜品  单品菜品可能内含配料菜
         */
        List<KBPreMenuItemModel> singleMenuItemLists = new ArrayList<>();

        /**
         * 单品配料明细 key-->fiItemCd   value-->List<KBPreMenuItemModel>
         *     归属于单品里面去 从列表移除
         */
        HashMap<String, ArrayList<KBPreMenuItemModel>> selectedModifierMap = new HashMap<>();

        Iterator<KBPreMenuItemModel> iterator = orderCache.dish_details.iterator();
        while (iterator.hasNext()) {
            KBPreMenuItemModel dish_detail = iterator.next();

            switch (dish_detail.type) {
                //套餐
                case "COMBO":
                    //套餐头 当main_flag为true， type为COMBO
                    if (dish_detail.main_flag) {
                        packageHeaderLists.add(dish_detail);
                        continue;
                    }
                    //套餐明细信息 当main_flag为false， type为COMBO，main_out_detail_no不为空
                    if (!dish_detail.main_flag && !TextUtils.isEmpty(dish_detail.main_out_detail_no)) {
                        ArrayList<KBPreMenuItemModel> tempMap = packageDetailsMap.get(dish_detail.main_out_detail_no);
                        if (tempMap == null) {
                            tempMap = new ArrayList<>();
                        }
                        tempMap.add(dish_detail);
                        packageDetailsMap.put(dish_detail.main_out_detail_no, tempMap);
                        continue;
                    }
                    break;
                //单品
//                case "SINGLE":
//                    //单品头 当main_flag为true， type为SINGLE
////                    if (dish_detail.main_flag) {
////                        singleMenuItemLists.add(dish_detail);
////                        continue;
////                    }
//                    singleMenuItemLists.add(dish_detail);
//                    break;
                //配料
                case "SIDE":
                    //单品配料明细信息 当main_flag为false， type为SIDE，main_out_detail_no不为空
//                    if (!dish_detail.main_flag && !TextUtils.isEmpty(dish_detail.main_out_detail_no)) {
//                        ArrayList<KBPreMenuItemModel> tempMap = selectedModifierMap.get(dish_detail.main_out_detail_no);
//                        if (tempMap == null) {
//                            tempMap = new ArrayList<>();
//                        }
//                        tempMap.add(dish_detail);
//                        selectedModifierMap.put(dish_detail.main_out_detail_no, tempMap);
//                        continue;
//                    }

                    /**
                     * 配料菜 main_flag = false
                     *    main_out_detail_no肯定不为空 不需要判断
                     */
                    ArrayList<KBPreMenuItemModel> tempMap = selectedModifierMap.get(dish_detail.main_out_detail_no);
                    if (tempMap == null) {
                        tempMap = new ArrayList<>();
                    }
                    tempMap.add(dish_detail);
                    selectedModifierMap.put(dish_detail.main_out_detail_no, tempMap);
                    break;
                //单品
                case "SINGLE":
                default:
                    //单品头 当main_flag为true， type为SINGLE
//                    if (dish_detail.main_flag) {
//                        singleMenuItemLists.add(dish_detail);
//                        continue;
//                    }
                    singleMenuItemLists.add(dish_detail);
                    break;

            }
        }

        //组装套餐数据 先付款套餐头和套餐明细拼接 【不可能出现只有套餐明细 没有套餐头的情况】
        for (KBPreMenuItemModel packageHeader : packageHeaderLists) {
            List<KBPreMenuItemModel> tempPackageDetails = packageDetailsMap.get(packageHeader.out_detail_no);
            if (!ListUtil.isEmpty(tempPackageDetails)) {
                for (KBPreMenuItemModel tempPackageDetail : tempPackageDetails) {
                    //todo 给套餐明细赋值套餐头名称 为了打印方便处理
                    tempPackageDetail.parentName = packageHeader.dish_name;
                    //套餐头的备注需要赋值到套餐明细菜品上
                    StringBuilder sb = new StringBuilder();
                    if (!TextUtils.isEmpty(packageHeader.memo)) {
                        sb.append(packageHeader.memo).append("*").append(tempPackageDetail.memo);
                    }
                    tempPackageDetail.memo = sb.toString();
                    packageHeader.packageMenuItemDetails.add(tempPackageDetail);
                }
            }
        }

        //组装单品配料数据 先付款单品头和单品配料明细拼接 【不可能出现只有单品明细 没有单品头的情况】
        for (KBPreMenuItemModel singleMenuItemHeader : singleMenuItemLists) {
            List<KBPreMenuItemModel> selectedModifierDetails = selectedModifierMap.get(singleMenuItemHeader.out_detail_no);
            if (!ListUtil.isEmpty(selectedModifierDetails)) {
                //todo 目前的格式 配料菜只能拆 不能合 需要把含有配料菜的菜品拆分成单个菜品信息
                for (int k = 0; k < selectedModifierDetails.size(); k++) {
                    //todo 给套餐明细赋值套餐头名称 为了打印方便处理
                    KBPreMenuItemModel item = selectedModifierDetails.get(k);
                    item.parentName = singleMenuItemHeader.dish_name;

                    //todo 重新计算配料的菜品数量以及总价
                    item.dish_total_amount = item.sell_price.multiply(item.dish_num);
                    //口碑配料菜并没有传规格单位需要自己查询
                    item.dish_unit = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsOrderUint from tbmenuitemuint where fiOrderUintCd='" + item.fiOrderUintCd + "' ");
                    //套餐头的备注需要赋值到套餐明细菜品上
                    StringBuilder sb = new StringBuilder();
                    if (!TextUtils.isEmpty(singleMenuItemHeader.memo)) {
                        sb.append(singleMenuItemHeader.memo).append("*").append(item.memo);
                    }
                    item.memo = sb.toString();
                    singleMenuItemHeader.selectedModifier.add(item);
                    //todo 口碑单品价格 包含配料菜价格  为了美易点统计 需要从单品中移除配料菜的价格
                    singleMenuItemHeader.sell_price = singleMenuItemHeader.sell_price.subtract(item.sell_price.multiply(item.dish_num));
                    singleMenuItemHeader.member_price = singleMenuItemHeader.member_price.subtract(item.sell_price.multiply(item.dish_num));
                }
            }
        }

        //todo 目前的格式 配料菜只能拆 不能合 需要把含有配料菜的菜品拆分成单个菜品信息
        Iterator<KBPreMenuItemModel> itemModelIterator = singleMenuItemLists.iterator();
        List<KBPreMenuItemModel> cloneModifierMenu = new ArrayList<>();
        while (itemModelIterator.hasNext()) {
            KBPreMenuItemModel singleMenuItemHeader = itemModelIterator.next();
            if (!ListUtil.isEmpty(singleMenuItemHeader.selectedModifier)) {
                if (singleMenuItemHeader.dish_num.intValue() > 1) {
                    //先移除
                    itemModelIterator.remove();
                    for (int d = 0; d < singleMenuItemHeader.dish_num.intValue(); d++) {
                        try {
                            KBPreMenuItemModel clone1 = (KBPreMenuItemModel) singleMenuItemHeader.clone();
                            clone1.dish_num = BigDecimal.ONE;
                            //singleMenuItemLists.add(clone1);
                            cloneModifierMenu.add(clone1);
                        } catch (CloneNotSupportedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
        singleMenuItemLists.addAll(cloneModifierMenu);



        //todo 需要统计的菜品
        List<KBPreMenuItemModel> originMenuItemLists = new ArrayList<>();
        //单品头 可能包含配料菜
        originMenuItemLists.addAll(singleMenuItemLists);
        //套餐
        originMenuItemLists.addAll(packageHeaderLists);
        return originMenuItemLists;
    }


    /**
     * 改变订单的状态
     *
     * @param order_id
     * @param status   订单的状态
     */
    public static void update(String order_id, String status) {

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set status = '" + status + "' where  order_id = '" + order_id + "'");
    }


    /**
     * 修改口碑先付款扫码桌台订单  改变桌台的名称
     *
     * @param order_id
     * @param fsmtablename   桌台的名称
     */
    public static void updateTableName(String order_id, String fsmtablename) {

        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, "update kbOrder set take_no = '" + fsmtablename + "' where  order_id = '" + order_id + "'");
    }



    /**
     * 查询
     *
     * @param order_id
     * @return
     */
    public static KBPreOrderCache query(String order_id) {

        String sql = "select * from kbOrder where order_id = '" + order_id + "'";
        KBPreOrderCache preOrderCache = DBSimpleUtil.query(APPConfig.DB_MAIN, sql, KBPreOrderCache.class);
        if (preOrderCache != null) {
            List<KBPreMenuItemModel> dish_details = JSON.parseArray(preOrderCache.menuItemListInfo, KBPreMenuItemModel.class);
            if (!ListUtil.isEmpty(dish_details)) {
                preOrderCache.dish_details = dish_details;
            }
            List<PosBillPayChannel> pay_channels = JSON.parseArray(preOrderCache.payListInfo, PosBillPayChannel.class);
            if (!ListUtil.isEmpty(pay_channels)) {
                preOrderCache.pay_channels = JSON.parseArray(preOrderCache.payListInfo, PosBillPayChannel.class);
            }
        }
        return preOrderCache;
    }

    /**
     * 查询口碑商户id
     *
     * @param order_id
     * @return
     */
    public static String queryMerchantId(String order_id) {
        String sql = "select merchant_id from kbOrder where order_id = '" + order_id + "'";
        return DBSimpleUtil.queryString(APPConfig.DB_MAIN, sql);
    }

    //存报表
    public static synchronized void saveBill(KBPreOrderCache preOrderCache) {
        //第三方菜品转本地菜品
        ArrayList<MenuItem> tempSelectedMenuList = KBOrderUtils.copyTo((ArrayList<KBPreMenuItemModel>) preOrderCache.dish_details, preOrderCache.memo);
        UserDBModel userDBModel = UserCache.getInstance().getCloudUser();
        OrderCache orderCache = KBOrderUtils.newOrderCache(preOrderCache, false);
        FastFoodDBUtil.save(orderCache, 1);
        KBOrderUtils.addMenuItems(orderCache, tempSelectedMenuList, userDBModel);
        //订单入库
        OrderSession.getInstance().writeOrder(orderCache.orderID, orderCache, true, "acceptPreOrder");
        trace(preOrderCache.order_id, "本地单号id[" + orderCache.orderID + "] 订单入库成功", orderCache);

//<<<<<<< HEAD
        PaySession paySession = KBOrderUtils.newPaySession(preOrderCache, orderCache, userDBModel);
        //写入支付明细
        OrderSession.getInstance().writePay(orderCache.orderID, true);
        trace(preOrderCache.order_id, "本地单号id[" + orderCache.orderID + "] 支付明细入库成功", paySession);
        PayProcessor.manualSetPaySuccess(orderCache, orderCache.orderID, "", userDBModel, HostBiz.cloudsite);
        //更新快餐订单业务状态
        FastFoodBusinessUtil.updateOrderBizStatus(orderCache.orderID, 2);
    }


    private static void trace(String kbOrderId, String msg, Object object) {
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "kbOrderId[" + kbOrderId + "] ->" + msg, "", object);
    }


    private static PayModel buildPayModel(UserDBModel userDBModel, String fsPaymentId, BigDecimal amt) {

        PayModel payModel = new PayModel(userDBModel.fsUserId, userDBModel.fsUserName);
        payModel.updateTime = DateUtil.getCurrentTime();
        payModel.updateWaiterID = userDBModel.fsUserId;
        payModel.updateWaiterName = userDBModel.fsUserName;
        payModel.hostID = HostBiz.cloudsite;
        payModel.status = PayTypeStatus.ENABLE;
        payModel.changeAmount = BigDecimal.ZERO;
        payModel.seq = 1;

        payModel.payAmount = amt;
        payModel.data = OrderUtil.buildPayModelByPaymentID(fsPaymentId);
        if (payModel.data == null) {
            payModel.data = OrderUtil.buildPayModelByPaymentID(PayType.RMB);
        }

        //切换为第三方订单支付
        payModel.writeThirdOrder();

        return payModel;
    }


    /**
     * 口碑预点单退款
     * 1 反结账
     * 2 退菜 支付方式要不要退
     * 3 0元结账
     * 4 通知界面刷新
     *
     * @param head
     * @param kbPreOrderCache
     * @param refundAction    是否是C端用户发起退款
     */
    public static void doAntiPayZeroBill(SocketHeader head, KBPreOrderCache kbPreOrderCache, @RefundAction int refundAction) {

        String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select * from order_cache where thirdOrderId = '" + kbPreOrderCache.order_id + "'");
        if (TextUtils.isEmpty(local_order_id)) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "本地订单数据已经被清除 不能进行整单退菜 0元结账 [  " + JSON.toJSONString(kbPreOrderCache) + "  ]");
            return;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(local_order_id);
        if (!TextUtils.equals(orderCache.businessDate, HostUtil.getHistoryBusineeDate(""))) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "订单的营业日期和口碑预点单的营业日期不相等 不能进行整单退菜 0元结账");
            return;
        }

        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 进行0元结账--->订单详情为", JSON.toJSONString(orderCache), JSON.toJSON(kbPreOrderCache));

        UserDBModel userDBModel = UserCache.getInstance().getCloudUser();

        //todo 反结账
        BillUtil.antiPayOrderStatus(orderCache, userDBModel, orderCache.orderID, "口碑预点单0元结账");

        //todo 退菜
        for (int j = 0; j < orderCache.originMenuList.size(); j++) {
            MenuItem temp = orderCache.originMenuList.get(j);
            temp.doVoid(temp.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "口碑预点单0元结账");

            if (!ListUtil.isEmpty(temp.menuBiz.selectedPackageItems)) {
                for (MenuItem item : temp.menuBiz.selectedPackageItems) {
                    item.doVoid(item.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "口碑预点单0元结账");
                }
            }

            temp.calcTotal(orderCache.isMember);
        }
        orderCache.totalPrice = BigDecimal.ZERO;
        orderCache.totalMenuPrice = BigDecimal.ZERO;
        orderCache.totalService = BigDecimal.ZERO;
        orderCache.plusAllMenuAmount();

        //订单置为未支付
        //删除支付方式
        for (PayModel payModel : OrderSession.getInstance().getPay(orderCache.orderID).selectPayListFull) {
            payModel.status = 13;
        }
        OrderSession.setPayed(orderCache.orderID, 0);

        //预约时间
        Long appointTime = DateTimeUtil.getLongByTimeReal(kbPreOrderCache.table_time, "yyyy-MM-dd HH:mm:ss");
        //当前时间
        Long currentTime = System.currentTimeMillis();
        //预约用餐时间30分钟以内
        boolean isPayPenalty = (appointTime - currentTime) < 30 * 60 * 1000;
        LogUtil.logBusiness("refundAction=" + refundAction + ",isPayPenalty=" + isPayPenalty + "   订单号=" + kbPreOrderCache.order_id);
        if (refundAction == RefundAction.ACTION_CUSTOMER && isPayPenalty) {
            //3.4.2口碑点餐新增字段【违约金】实现：
            //构建临时菜菜品，更新orderCache.
            //违约金
            BigDecimal penalty = null;
            JSONObject jsonObject = null;
            try {
                jsonObject = JSONObject.parseObject(kbPreOrderCache.ext_info);
                String mBuyerDefaultRealAmount = jsonObject.getString("buyerDefaultRealAmount");
                penalty = new BigDecimal(mBuyerDefaultRealAmount);
            } catch (Exception e) {
                penalty = BigDecimal.ZERO;
                LogUtil.logBusiness("[违约金]解析失败" + orderCache.orderID + "ext_info:" + jsonObject);
            }

            MenuItem menuItem = KBOrderUtils.generatePenaltyTempMenu("违约金", penalty, orderCache.currentSeq);
            orderCache.originMenuList.add(0, menuItem);
            orderCache.updateSeqStatus(orderCache.currentSeq, OrderSeqStatus.ORDERED, userDBModel, HostBiz.cloudsite);
            orderCache.currentSeq++;
            orderCache.totalPrice = penalty;
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "【违约金】临时菜品构建成功");

            //重新保存订单
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "doAntiPayZeroBill");
//            OrderProcessor.saveOrder(orderCache, null);
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "【违约金】订单入库成功");

            //构建支持明细
            PaySession paySession = OrderSession.getInstance().generatePaySession(orderCache, userDBModel, HostBiz.cloudsite);
            PayModel payModel = buildPayModel(userDBModel, PayType.ALIPAY_PENALTY, penalty);
            paySession.selectPayListFull.add(payModel);
            //写入支付明细
            OrderSession.getInstance().writePay(orderCache.orderID, true);
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "【违约金】支付明细写入成功");
            //结账
            head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            BillUtil.startFinalPayProcess(head.ot, orderCache.orderID, userDBModel, head.hd, true, false);
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "【违约金】临时菜结账完成");

            if (!TextUtils.isEmpty(orderCache.fsmareaid)) {
                TableDBUtil.releaseTableBizById(orderCache.fsmtableid);
                ServerCache.getInstance().releaseTableQR(orderCache.fsmtableid);
            }
        } else {
            //保持3.4.2口碑点餐新增字段「违约金」未加之前逻辑
            //重新保存订单
            OrderSession.getInstance().writeOrder(orderCache.orderID, true, "doAntiPayZeroBill 2");
//            OrderProcessor.saveOrder(orderCache, null);

            //todo  清除桌台业务表  0元结账
            head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            BillUtil.startFinalPayProcess(head.ot, orderCache.orderID, userDBModel, head.hd, true, false);

            //todo 有问题的方法强制处理一次 防止0元结账出现问题 这时候需要把桌台业务关联关系直接解除 不能影响用户下一步操作的行为
            if (!TextUtils.isEmpty(orderCache.fsmareaid)) {
                TableDBUtil.releaseTableBizById(orderCache.fsmtableid);
                ServerCache.getInstance().releaseTableQR(orderCache.fsmtableid);
            }
        }
        //todo 通知界面刷新
        NotifyToClient.orderChange(orderCache.orderID);
        NotifyToClient.clearDishCache();
    }

    /**
     * 查询口碑当前【备餐中】状态的订单数量 and 本地order_cache未结账订单数量；
     *
     * @return
     */
    public static int unCheckoutAndPrepareNum() {
        int sum = 0;
        String uncheckoutNum = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from order_cache where order_status='1'");
        if (!TextUtils.isEmpty(uncheckoutNum)) {
            sum = Integer.parseInt(uncheckoutNum.trim());
        }

        String prepareNum = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select count(*) from kbOrder where status='PREPARE'");
        if (!TextUtils.isEmpty(prepareNum)) {
            sum = sum + Integer.parseInt(prepareNum.trim());
        }

        return sum;
    }

    /**
     * 口碑预点单 部分 退款
     * 1 反结账
     * 2 退菜 支付方式要不要退
     * 3 重新结账
     * 4 通知界面刷新
     *
     * @param head
     * @param kbPreOrderCache
     */
    public static void doPartAntiPayZeroBill(SocketHeader head, KBPreOrderCache kbPreOrderCache, ArrayList<MenuItem> choiceRefundMenuList, KBPartRefundExtInfo extInfo) {
        String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select * from order_cache where thirdOrderId = '" + kbPreOrderCache.order_id + "'");
        if (TextUtils.isEmpty(local_order_id)) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "部分退款 本地订单数据已经被清除 不能进行部分退菜  [  " + JSON.toJSONString(kbPreOrderCache) + "  ]");
            return;
        }

        final OrderCache orderCache = OrderSession.getInstance().getOrder(local_order_id);
        if (!TextUtils.equals(orderCache.businessDate, HostUtil.getHistoryBusineeDate(""))) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "部分退款  订单的营业日期和口碑预点单的营业日期不相等 不能进行部分退菜 ");
            return;
        }
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表--->订单详情为", JSON.toJSONString(orderCache), JSON.toJSON(kbPreOrderCache));

        UserDBModel userDBModel = UserCache.getInstance().getCloudUser();

        //退款后的订单总金额= 订单总金额 - 退款金额
        BigDecimal tempTotalPrice = orderCache.totalPrice.subtract(extInfo.getRefund_amount());

        //获取之前所有的支付方式
        List<PayModel> selectPayListFull = OrderSession.getInstance().getPay(orderCache.orderID).selectPayListFull;
        BigDecimal oldMerchantsSubsidies = BigDecimal.ZERO;//退款前的商家补贴
        BigDecimal oldPlatformSubsidies = BigDecimal.ZERO;//退款前的平台补贴
        for (PayModel payModel : selectPayListFull) {
            if (TextUtils.equals(payModel.data.payTypeID, PayType.ALI_PLATFORM_MERCHANT_DISCOUNT)) {
                oldMerchantsSubsidies = payModel.payAmount;
            } else if (TextUtils.equals(payModel.data.payTypeID, PayType.ALI_DISCOUNT)) {
                oldPlatformSubsidies = payModel.payAmount;
            }
        }

        //计算退款后支付宝口碑支付的金额
        BigDecimal alipayKBPayAmount = alipayKBPay(kbPreOrderCache.pay_amount, extInfo.getBuyer_real_amount());

        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表",
                "  退款后支付宝口碑支付的金额：" + alipayKBPayAmount + "     退款前支付宝口碑实际支付金额：" +
                        kbPreOrderCache.pay_amount + "  买家实际退金额：" + extInfo.getBuyer_real_amount());

        BigDecimal KBMerchants = BigDecimal.ZERO;
        if (oldMerchantsSubsidies.compareTo(BigDecimal.ZERO) > 0) {
            //计算退款后支付宝商家补贴的金额
            KBMerchants = alipayKBMerchants(oldMerchantsSubsidies, oldPlatformSubsidies, extInfo.getRefund_amount(), extInfo.getBuyer_real_amount());
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表",
                    "  退款后支付宝商家补贴的金额：" + KBMerchants + "     退款前的支付宝商家补贴金额：" +
                            oldMerchantsSubsidies + "     退款前的支付宝平台补贴=" + oldPlatformSubsidies + "  订单总金额：" + kbPreOrderCache.bill_amount + "    退款金额：" + extInfo.getRefund_amount() + "     买家实际退金额：" + extInfo.getBuyer_real_amount());
        }

        BigDecimal platformSubsidies = BigDecimal.ZERO;
        if (oldPlatformSubsidies.compareTo(BigDecimal.ZERO) > 0) {
            //计算退款后支付宝平台补贴的金额
            platformSubsidies = alipayKBPlatform(oldPlatformSubsidies, oldMerchantsSubsidies, extInfo.getRefund_amount(), extInfo.getRefund_amount());

            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表",
                    "  退款后支付宝平台补贴的金额：" + platformSubsidies + "     退款前的支付宝平台补贴金额：" +
                            oldPlatformSubsidies + "    退款前的支付宝商家补贴：" + oldMerchantsSubsidies + "  订单总金额：" + kbPreOrderCache.bill_amount + "    退款金额：" + extInfo.getRefund_amount());
        }

        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表", "  退款后的订单总金额:" + tempTotalPrice + "     退款金额:" + extInfo.getRefund_amount());

        //计算退款后所有支付总金额
        BigDecimal allPayWayotalAmount = alipayKBPayAmount.add(KBMerchants).add(platformSubsidies);
        RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  准备修改报表", "  计算退款后所有支付方式总金额:" + allPayWayotalAmount);

        if (tempTotalPrice.compareTo(allPayWayotalAmount) != 0) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  终止修改报表", "订单异常  原因  部分退款后所有支付方式总金额不等于退款后订单总金额    退款后的订单总金额为:" + tempTotalPrice + "    所有支付方式总金额为:" + allPayWayotalAmount);
            return;
        }

        //todo 反结账
        BillUtil.antiPayOrderStatus(orderCache, userDBModel, orderCache.orderID, "口碑预点单部分退款");

        //todo 退掉选中的菜
        for (int i = 0; i < choiceRefundMenuList.size(); i++) {
            for (MenuItem menuItem : orderCache.originMenuList) {
                MenuItem model = choiceRefundMenuList.get(i);
                if (TextUtils.equals(model.menuBiz.uniq, menuItem.menuBiz.uniq)) {
                    menuItem.doVoid(model.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "口碑预点单部分退款");
                    if (!ListUtil.isEmpty(menuItem.menuBiz.selectedPackageItems)) {
                        for (MenuItem item : menuItem.menuBiz.selectedPackageItems) {
                            item.doVoid(item.menuBiz.buyNum, userDBModel.fsUserId, userDBModel.fsUserName, "口碑预点单0元结账");
                        }
                    }
                    menuItem.calcTotal(orderCache.isMember);
                }
            }
        }
        //退款后的订单总金额= 订单总金额 - 退款金额
        orderCache.totalPrice = tempTotalPrice;
        //todo 因为先付款的订单不需要重新计算 退款以后前端界面使用的是这个字段 所以要重新赋值
        orderCache.totalMenuPrice = tempTotalPrice;
        orderCache.totalService = BigDecimal.ZERO;
        orderCache.plusAllMenuAmount();
        //订单置为未支付
        //删除支付方式
        for (PayModel payModel : selectPayListFull) {
            payModel.status = 13;
        }

        //添加 支付宝口碑支付 支付方式
        selectPayListFull.add(buildPayModel(userDBModel, DBConstants.PAY_TYPE_KB_PAY, alipayKBPayAmount));
        if (oldMerchantsSubsidies.compareTo(BigDecimal.ZERO) > 0) {
            if (KBMerchants.compareTo(BigDecimal.ZERO) > 0) {
                //添加 支付宝商家补贴 支付方式
                selectPayListFull.add(buildPayModel(userDBModel, PayType.ALI_PLATFORM_MERCHANT_DISCOUNT, KBMerchants));
            }
        }

        if (oldPlatformSubsidies.compareTo(BigDecimal.ZERO) > 0) {
            if (platformSubsidies.compareTo(BigDecimal.ZERO) > 0) {
                //添加 支付宝商家补贴 支付方式
                selectPayListFull.add(buildPayModel(userDBModel, PayType.ALI_DISCOUNT, platformSubsidies));
            }
        }


        OrderSession.setPayed(orderCache.orderID, 0);
        //重新保存订单
        OrderSession.getInstance().writeOrder(orderCache.orderID, true, "doPartAntiPayZeroBill");
//        OrderProcessor.saveOrder(orderCache, null);

        //检查该订单是否已经结账清台
        String tableId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select fsmtableid from tableBiz where fssellno = '" + orderCache.orderID + "'");
        if (TextUtils.isEmpty(tableId)) {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  修改报表", "  订单已经结账清台或是快餐单 所以直接结账");
            //todo  清除桌台业务表  0元结账
            head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
            BillUtil.startFinalPayProcess(head.ot, orderCache.orderID, userDBModel, head.hd, true, false);
        } else {
            RunTimeLog.addLog(RunTimeLog.KBPRE_ORDER, "口碑预点单 部分退款  修改报表", "  订单未结账清台 所以不执行结账");
        }

        //todo  清除桌台业务表
//        head.ot = ServerCache.getInstance().generateNewToken(orderCache.orderID);
//        BillUtil.startFinalPayProcess(head.ot, orderCache.orderID, userDBModel, head.hd, true, false);
//
//        //todo 有问题的方法强制处理一次 结账出现问题 这时候需要把桌台业务关联关系直接解除 不能影响用户下一步操作的行为
//        if (!TextUtils.isEmpty(orderCache.fsmareaid)) {
//            TableDBUtil.releaseTableBizById(orderCache.fsmtableid);
//            ServerCache.getInstance().releaseTableQR(orderCache.fsmtableid);
//        }
        //todo 通知界面刷新
        NotifyToClient.orderChange(orderCache.orderID);
//        NotifyToClient.clearDishCache();
    }



    /**
     * 计算退款后支付宝口碑支付的金额
     *
     * @param oldPayAmount      退款前实际支付金额
     * @param buyer_real_amount 买家实际退金额
     * @return
     */
    public static BigDecimal alipayKBPay(BigDecimal oldPayAmount, BigDecimal buyer_real_amount) {
        //退款后支付宝口碑支付的金额 = 退款前支付宝口碑实际支付金额 -  买家实际退金额
        return oldPayAmount.subtract(buyer_real_amount);
    }

    /**
     * 计算退款后支付宝商家补贴的金额
     *
     * @param oldBuTieAmount    退款前的支付宝商家补贴金额
     * @param oldPingTaiAmount  退款前的支付宝平台补贴
     * @param refundAmount      退款金额
     * @param buyer_real_amount 买家实际退金额
     * @return
     */
    public static BigDecimal alipayKBMerchants(BigDecimal oldBuTieAmount, BigDecimal oldPingTaiAmount, BigDecimal refundAmount, BigDecimal buyer_real_amount) {
        //退款后支付宝商家补贴的金额 = 退款前的支付宝商家补贴金额 - [退款前的支付宝商家补贴金额 / (退款前的支付宝商家补贴+退款前的支付宝平台补贴） * (退款金额 - 买家实际退金额)]
        return oldBuTieAmount.subtract(oldBuTieAmount.divide(oldBuTieAmount.add(oldPingTaiAmount), 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP).multiply(refundAmount.subtract(buyer_real_amount)).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    /**
     * 计算退款后支付宝平台补贴的金额
     *
     * @param oldPingTaiAmount  退款前的支付宝平台补贴金额
     * @param oldBuTieAmount    退款前的支付宝商家补贴金额
     * @param refundAmount      退款金额
     * @param buyer_real_amount 买家实际退金额
     * @return
     */
    public static BigDecimal alipayKBPlatform(BigDecimal oldPingTaiAmount, BigDecimal oldBuTieAmount, BigDecimal refundAmount, BigDecimal buyer_real_amount) {
        //退款后支付宝平台补贴的金额 = 退款前的支付宝平台补贴金额 - [退款前的支付宝平台补贴金额 / （退款前的支付宝平台补贴金额+退款前的支付宝商家补贴） * (退款金额 - 买家实际退金额)]
        return oldPingTaiAmount.subtract(oldPingTaiAmount.divide(oldPingTaiAmount.add(oldBuTieAmount), 2, BigDecimal.ROUND_HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP).multiply(refundAmount.subtract(buyer_real_amount)).setScale(2, BigDecimal.ROUND_HALF_UP));
    }

    /**
     * 是否可以退款
     *
     * @return
     */
    public static OrderCache isCanRefund(String thirdOrderId) {
        //如果本地订单数据已经被清除 本地订单就无法退菜操作
        String local_order_id = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "select * from order_cache where thirdOrderId = '" + thirdOrderId + "'");
        if (TextUtils.isEmpty(local_order_id)) {
            return null;
        }

        OrderCache orderCache = OrderSession.getInstance().getOrder(local_order_id);
        //订单的营业日期和口碑预点单的营业日期不相等 本地订单不能进行退菜退款
        if (!TextUtils.equals(orderCache.businessDate, HostUtil.getHistoryBusineeDate(""))) {
            return null;
        }

        return orderCache;
    }
}
