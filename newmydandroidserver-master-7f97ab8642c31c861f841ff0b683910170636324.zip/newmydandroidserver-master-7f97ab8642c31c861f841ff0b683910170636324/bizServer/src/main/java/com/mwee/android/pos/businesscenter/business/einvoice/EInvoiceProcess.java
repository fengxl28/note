package com.mwee.android.pos.businesscenter.business.einvoice;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.mwee.android.base.net.ResponseData;
import com.mwee.android.base.task.BusinessExecutor;
import com.mwee.android.base.task.callback.BusinessCallback;
import com.mwee.android.base.task.callback.IExecutorCallback;
import com.mwee.android.pos.business.einvoice.api.InvoiceDetailRequest;
import com.mwee.android.pos.business.einvoice.api.InvoiceDetailResponse;
import com.mwee.android.pos.business.einvoice.model.InvoiceDetailBean;
import com.mwee.android.pos.businesscenter.business.system.GlobalLooper;
import com.mwee.android.pos.businesscenter.dbutil.ManualIEnvoiceDBUtil;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.businesscenter.framework.ServerCache;
import com.mwee.android.pos.component.log.RunTimeLog;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.DBMetaUtil;
import com.mwee.android.pos.db.base.META;
import com.mwee.android.pos.db.business.order.InvoiceState;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.sync.Constant;
import com.mwee.android.pos.util.JsonUtil;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;
import com.mwee.android.tools.MD5Util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * author:luoshenghua
 * create on:2018/5/5
 * description:电子发票二维码生成类.
 */
public class EInvoiceProcess {
    //166 POS订单开票业务,167 网络订单开票业务,168 美易点线下开票业务,172 小猫线下收银开票业务，并对应各自sign.
    public static final String SOURCE_ID = "168";
    private static final String SIGN = "@pQZRY1w9v";

    public static String optEInvoiceQR(String orderId, BigDecimal payMoney, String payTime) {
        String shopId = DBMetaUtil.getSettingsValueByKey(META.SHOPID);

        if (TextUtils.isEmpty(orderId)
                || TextUtils.isEmpty(shopId)
                || (payMoney.compareTo(BigDecimal.ZERO) <= 0)
                || TextUtils.isEmpty(SOURCE_ID)
                || TextUtils.isEmpty(SIGN)
                || TextUtils.isEmpty(payTime)) {
            String logStr = "电子发票二维码生成失败 shopId = " + shopId + "|orderId=" + orderId + "|payMondy=" + payMoney + "|payTime=" + payTime;
            LogUtil.log(logStr);
            RunTimeLog.addLog(RunTimeLog.PRINT_EINVOICE_QR, logStr);
            return null;
        }

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("orderid", orderId);
        paramsMap.put("shopId", shopId);
        paramsMap.put("paymoney", String.valueOf(payMoney));
        paramsMap.put("paytime", payTime);
        paramsMap.put("sourceId", SOURCE_ID);

        String md5Secret = createSecret(paramsMap, SIGN);


        StringBuilder paramsQRBuilder = new StringBuilder();
        paramsQRBuilder.append(Constant.getEInvoiceQRUrlRoot());
        paramsQRBuilder.append("?");
        paramsQRBuilder.append("orderid=");
        paramsQRBuilder.append(orderId);
        paramsQRBuilder.append("&");
        paramsQRBuilder.append("shopId=");
        paramsQRBuilder.append(shopId);
        paramsQRBuilder.append("&");
        paramsQRBuilder.append("paymoney=");
        paramsQRBuilder.append(payMoney);
        paramsQRBuilder.append("&");
        paramsQRBuilder.append("paytime=");
        paramsQRBuilder.append(payTime);
        paramsQRBuilder.append("&");
        paramsQRBuilder.append("sourceId=");
        paramsQRBuilder.append(SOURCE_ID);
        paramsQRBuilder.append("&");
        paramsQRBuilder.append("sign=");
        paramsQRBuilder.append(md5Secret);

        return paramsQRBuilder.toString();
    }

    private static String createSecret(Map<String, String> paramsMap, String sign) {
        StringBuilder secretBuilder = new StringBuilder();
        //按key升序排序
        Object[] keyArray = paramsMap.keySet().toArray();
        Arrays.sort(keyArray);

        for (Object key : keyArray) {
            secretBuilder.append(key);
            Object value = paramsMap.get(key);
            secretBuilder.append(value);
        }
        secretBuilder.append(sign);
        //这里不处理，会签名校验不通过.
        String tempStr = secretBuilder.toString().replace("\n", "").trim();
        String md5Secret = MD5Util.getMD5String(tempStr);

        return md5Secret;
    }


    /**
     * 获取电子发票详情
     *
     * @param sourceId
     * @param businessNoStrs
     * @param callback
     */
    private static void getEInvoiceDetails(String sourceId, String businessNoStrs, IExecutorCallback callback) {
        InvoiceDetailRequest invoiceDetailRequest = new InvoiceDetailRequest();
        invoiceDetailRequest.businessNo = businessNoStrs;
        invoiceDetailRequest.sourceId = sourceId;
        BusinessExecutor.execute(invoiceDetailRequest, callback);
    }

    /**
     * 更新数据库电子发票状态
     *
     * @param invoiceState          电子发票开具状态
     * @param business_no           订单流水号
     * @param serial_no             电子发票请求流水号
     * @param invoiceDetailBeanJson 电子发票详情Json
     */

    public static void updateEInvoiceStatus(String business_no, int invoiceState, String serial_no, String invoiceDetailBeanJson) {
        String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsSellNo FROM tbSell WHERE invoiceBusinessNo = '" + business_no + "'");
        if (!TextUtils.isEmpty(orderId)) {
            recordEInvoiceStatus(business_no, invoiceState, invoiceDetailBeanJson);
        }

        String tbsellsSql = "update tbsell set fiInvoiceState='" + invoiceState + "',fsInvoiceNo='" + serial_no + "' where invoiceBusinessNo = '" + business_no + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, tbsellsSql);
    }

    /**
     * 记录已打印开具电子发票二维码结账单
     *
     * @param invoiceState          电子发票开具状态
     * @param orderId               订单号
     * @param invoiceDetailBeanJson 电子发票详情Json
     */
    public static void recordEInvoiceStatus(String orderId, int invoiceState, String invoiceDetailBeanJson) {
        String orderCacheSql = "update order_cache set invoiceState='" + invoiceState + "',invoiceDetail='" + invoiceDetailBeanJson + "' where order_id = '" + orderId + "'";
        DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, orderCacheSql);
    }

    /**
     * 根据明细更新电子发票状态
     *
     * @param detail InvoiceDetailBean | 电子发票详情
     */
    public static void updateByDetail(InvoiceDetailBean detail) {
        if (detail == null) {
            return;
        }
        if (TextUtils.isEmpty(detail.business_no)) {
            return;
        }

        // 根据电子发票流水号获取美易点订单号
        String orderId = DBSimpleUtil.queryString(APPConfig.DB_MAIN, "SELECT fsSellNo FROM tbSell WHERE invoiceBusinessNo = '" + detail.business_no + "'");
        if (TextUtils.isEmpty(orderId)) {
            return;
        }

        int state = InvoiceState.NO_INVOICING;
        //0:不开票；1：需要开票（打印过开票二维码） 2：开票成功  3：开票中 4：开票失败
        if (TextUtils.equals("SUCCESS", detail.trade_state)) {
            state = InvoiceState.INVOICE_SUCCESS;
        } else if (TextUtils.equals("PROCESSING", detail.trade_state)) {
            state = InvoiceState.INVOICE_PROCESSING;
        } else if (TextUtils.equals("FAIL", detail.trade_state)) {
            state = InvoiceState.INVOICE_FAILURE;
        }

        String uniq = ServerCache.getInstance().tableLockCache.doLock("", orderId, "修改电子发票开票状态");
        try {
            OrderCache orderCache = OrderSession.getInstance().getOrder(orderId);
            // 如果 OrderCache 还在缓存中, 需要更新 OrderCache
            if (orderCache != null) {
                orderCache.invoiceState = state;
                orderCache.invoiceDetailBean = detail;
                RunTimeLog.addLog(RunTimeLog.XMPP_PUSH_MESSAGE, "电子发票开票状态->" + orderId + "|" + orderCache.invoiceState);
                EInvoiceProcess.updateEInvoiceStatus(detail.business_no, orderCache.invoiceState, detail.serial_no, JSON.toJSONString(detail));
                OrderSession.getInstance().writeOrder(orderId, true, "updateByDetail");
            } else {
                String tbsellsSql = "UPDATE tbSell SET fiInvoiceState='" + state + "', fsInvoiceNo = '" + detail.serial_no + "' WHERE invoiceBusinessNo = '" + detail.business_no + "'";
                DBSimpleUtil.excuteSql(APPConfig.DB_MAIN, tbsellsSql);
            }
        } finally {
            ServerCache.getInstance().tableLockCache.unLock(uniq, "", orderId, "修改电子发票开票状态");
        }
    }

    /**
     * 递归请求电子发票详情
     */
    public static void recursionEInvoiceDetails(List<String> divideList, int index) {
        if (index < divideList.size()) {
            String businessNoStrs = divideList.get(index);
            if (!TextUtils.isEmpty(businessNoStrs)) {
                EInvoiceProcess.getEInvoiceDetails(EInvoiceProcess.SOURCE_ID, businessNoStrs, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        if (responseData.responseBean != null && responseData.responseBean instanceof InvoiceDetailResponse) {
                            InvoiceDetailResponse invoiceDetailResponse = (InvoiceDetailResponse) responseData.responseBean;
                            if (invoiceDetailResponse != null) {
                                ArrayList<InvoiceDetailBean> invoiceRateBeanList = invoiceDetailResponse.data;
                                if (invoiceRateBeanList != null) {
                                    for (int i = 0; i < invoiceRateBeanList.size(); i++) {
                                        InvoiceDetailBean invoiceDetailBean = invoiceRateBeanList.get(i);
                                        EInvoiceProcess.updateByDetail(invoiceDetailBean);
                                    }
                                }
                            }
                        }
                        GlobalLooper.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                recursionEInvoiceDetails(divideList, index + 1);
                            }
                        }, 2000);
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        GlobalLooper.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                recursionEInvoiceDetails(divideList, index + 1);
                            }
                        }, 2000);
                        return false;
                    }
                });
            }
        }
    }

    /**
     * 刷新手动纯开票状态
     *  过滤掉已开票成功的数据
     *
     * @param date
     */
    public static void updateManualEInvoceingStatus(String date) {
        String sql = "SELECT orderId FROM manualInvoicing WHERE status <> 20 and date = '" + date + "' ";
        List<String> orderIdList = DBSimpleUtil.queryStringList(APPConfig.DB_MAIN, sql);
        if (!ListUtil.isEmpty(orderIdList)) {
            //每次最多请求10条，分多次请求发票详情接口，减轻服务器压力
            int perMax = 10;
            List<String> paramList = new ArrayList<>();
            if (orderIdList.size() <= perMax) {
                paramList.add(ListUtil.listToStr(orderIdList, ","));
            } else {
                List<String> tempList = new ArrayList<>();
                for (int i = 0; i < orderIdList.size(); i++) {
                    tempList.add(orderIdList.get(i));
                    if (i != 0 && (i + 1) % perMax == 0 || (i + 1) == orderIdList.size()) {
                        paramList.add(ListUtil.listToStr(tempList, ","));
                        tempList.clear();
                    }
                }
            }

            InvoiceDetailRequest invoiceDetailRequest = new InvoiceDetailRequest();
            invoiceDetailRequest.sourceId = EInvoiceProcess.SOURCE_ID;

            for (String orderIds : paramList) {
                invoiceDetailRequest.businessNo = orderIds;
                BusinessExecutor.execute(invoiceDetailRequest, new IExecutorCallback() {
                    @Override
                    public void success(ResponseData responseData) {
                        if (responseData.responseBean instanceof InvoiceDetailResponse) {
                            InvoiceDetailResponse invoiceDetailResponse = (InvoiceDetailResponse) responseData.responseBean;
                            ArrayList<InvoiceDetailBean> invoiceRateBeanList = invoiceDetailResponse.data;
                            if (!ListUtil.isEmpty(invoiceRateBeanList)) {
                                for (InvoiceDetailBean invoiceDetailBean : invoiceRateBeanList) {

                                    int state = 0;
                                    //0:未开票； 10：开票中； 20：开票成功； 30开票失败
                                    if (TextUtils.equals("SUCCESS", invoiceDetailBean.trade_state)) {
                                        state = 20;
                                    } else if (TextUtils.equals("PROCESSING", invoiceDetailBean.trade_state)) {
                                        state = 10;
                                    } else if (TextUtils.equals("FAIL", invoiceDetailBean.trade_state)) {
                                        state = 30;
                                    }

                                    ManualIEnvoiceDBUtil.updateStatus(invoiceDetailBean.business_no, state, invoiceDetailBean.trade_state_reason);
                                }
                            }
                        }

                        LogUtil.logBusiness("更新手动开发票状态异常 IExecutorCallback success ");
                    }

                    @Override
                    public boolean fail(ResponseData responseData) {
                        LogUtil.logBusiness("更新手动开发票状态异常 invoiceDetailRequest = " + JSON.toJSONString(invoiceDetailRequest), JSON.toJSONString(responseData));
                        return false;
                    }
                }, new BusinessCallback() {

                    @Override
                    public boolean success(int i, ResponseData responseData) {
                        return false;
                    }

                    @Override
                    public boolean fail(int i, ResponseData responseData) {
                        return false;
                    }
                }, false);
                try {
                    Thread.sleep(20);
                }catch (Exception e){

                }
            }

        }

    }
}
