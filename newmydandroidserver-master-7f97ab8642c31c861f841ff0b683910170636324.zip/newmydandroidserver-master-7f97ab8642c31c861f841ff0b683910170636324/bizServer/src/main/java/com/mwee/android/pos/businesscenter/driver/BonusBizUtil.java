package com.mwee.android.pos.businesscenter.driver;

import android.text.TextUtils;

import com.mwee.android.pos.business.bonus.BonusUtils;
import com.mwee.android.pos.businesscenter.framework.OrderSession;
import com.mwee.android.pos.connect.business.bind.HostUtil;
import com.mwee.android.pos.db.APPConfig;
import com.mwee.android.pos.db.business.SellOrderItemBonusDBModel;
import com.mwee.android.pos.db.business.common.OrderProcessor;
import com.mwee.android.pos.db.business.menu.bean.MenuItem;
import com.mwee.android.pos.db.business.order.OrderCache;
import com.mwee.android.pos.db.business.order.bonus.BonusUserModel;
import com.mwee.android.pos.util.ListUtil;
import com.mwee.android.sqlite.base.DBSimpleUtil;
import com.mwee.android.tools.LogUtil;

import java.util.ArrayList;
import java.util.List;

public class BonusBizUtil {

    /**
     * 获取所有提成人-菜
     */
    public static List<BonusUserModel> queryAllBonusUser() {
        String shopGUID = HostUtil.getShopID();
        String sql = "SELECT tbBonusManageUser.fsBonusMenuGuid,tbBonusManageUser.fsUserId,tbUser.fsUserName," +
                " tbBonusManageMenu.fiItemCd,tbBonusManageMenu.fiOrderUintCd " +
                " FROM (tbBonusManageUser INNER JOIN tbUser ON tbBonusManageUser.fsUserId=tbUser.fsUserId)" +
                " INNER JOIN tbBonusManageMenu ON tbBonusManageUser.fsBonusMenuGuid=tbBonusManageMenu.fsBonusMenuGuid " +
                " INNER JOIN tbBonusMenu ON tbBonusMenu.fsBonusMenuGuid=tbBonusManageUser.fsBonusMenuGuid " +
                " INNER JOIN tbMenuItem ON tbBonusManageMenu.fiItemCd=tbMenuItem.fiItemCd " +
                " WHERE tbBonusManageUser.fsShopGUID='" + shopGUID + "' AND tbBonusManageUser.fiStatus='1' " +
                " AND tbBonusManageMenu.fsShopGUID='" + shopGUID + "' AND tbBonusManageMenu.fiStatus='1' " +
                " AND tbBonusMenu.fsShopGUID='" + shopGUID + "' AND tbBonusMenu.fiStatus='1' " +
                " AND tbUser.fsShopGUID='" + shopGUID + "' AND tbUser.fiStatus='1' " +
                " AND tbMenuItem.fsShopGUID='" + shopGUID + "' AND tbMenuItem.fiIsBonus='1' ";
        List<BonusUserModel> bonusUserList = DBSimpleUtil.queryList(APPConfig.DB_MAIN, sql, BonusUserModel.class);
        if (ListUtil.isEmpty(bonusUserList)) {
            bonusUserList = new ArrayList<>();
        }
        return bonusUserList;
    }

    /**
     * 更新已下单菜品提成人
     *
     * @param orderCache    订单
     * @param bonusMenuList 提成菜品列表
     */
    public static void updateBonus(OrderCache orderCache, List<MenuItem> bonusMenuList) {
        if (orderCache == null) {
            return;
        }

        if (!ListUtil.isEmpty(orderCache.originMenuList)) {
            BonusUtils.copyBonusInfo(orderCache.originMenuList, bonusMenuList);
        }
    }

    /**
     * 更新已下单菜品提成人
     *
     * @param orderCache    订单
     * @param bonusItemList 提成菜品列表
     */
    public static void updateBonusBySell(OrderCache orderCache, List<SellOrderItemBonusDBModel> bonusItemList) {
        if (orderCache == null || ListUtil.isEmpty(orderCache.originMenuList) || ListUtil.isEmpty(bonusItemList)) {
            return;
        }
        for (SellOrderItemBonusDBModel bonusItem : bonusItemList) {
            if (bonusItem == null) {
                continue;
            }
            for (MenuItem item : orderCache.originMenuList) {
                if (item == null || item.menuBiz == null) {
                    continue;
                }
                if (TextUtils.equals(item.menuBiz.uniq, bonusItem.fsSeq)) {
                    item.menuBiz.addConfig(128);
                    item.menuBiz.bonusAuthorizerId = bonusItem.fsBonusCertigierUserId;
                    item.menuBiz.bonusUserId = bonusItem.fsBonusUserId;
                    if (!ListUtil.isEmpty(item.menuBiz.selectedModifier)) {
                        for (MenuItem modifier : item.menuBiz.selectedModifier) {
                            modifier.menuBiz.addConfig(128);
                            modifier.menuBiz.bonusAuthorizerId = bonusItem.fsBonusCertigierUserId;
                            modifier.menuBiz.bonusUserId = bonusItem.fsBonusUserId;
                        }
                    }
                }
            }
        }
    }

    public static void mergeBonusToMenuItem(List<MenuItem> menuItemList, List<SellOrderItemBonusDBModel> itemBonusList) {
        if (ListUtil.isEmpty(menuItemList) || ListUtil.isEmpty(itemBonusList)) {
            LogUtil.logBusiness("菜品列表或提成信息列表为空");
            return;
        }

        for (MenuItem menuItem : menuItemList) {
            for (SellOrderItemBonusDBModel bonusItem : itemBonusList) {
                if (TextUtils.equals(menuItem.menuBiz.uniq, bonusItem.fsSeq) &&
                        TextUtils.equals(menuItem.itemID, bonusItem.fiItemCd) &&
                        TextUtils.equals(menuItem.currentUnit.fiOrderUintCd, bonusItem.fiOrderUintCd)) {
                    BonusUtils.setMenuItemBonusUser(menuItem, bonusItem.fsBonusUserId, bonusItem.fsBonusCertigierUserId);
                }
            }
        }
        return;
    }
}
