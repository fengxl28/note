# 项目初始化
```
    cd <项目根目录>
    git submodule init

    //若提示fatal: destination path '<path>' already exists and is not an empty directory,需要先删除<path>目录
    git submodule update
    //调整submodule分支：团队现在严格按照"module-submodule"版本一致原则
    进入submodule根目录，"git checkout <主module版本号>"
```

# 业务中心插件使用流程(老版本)
## 适用于老版本，server同源
1.配置插件copy目标地址
```
    ./serverShell/shell.properties下配置path参数
    示例："path=/Users/root.eric/Diskette/WorkSpace/mydandroidshell"
```
2.编译插件apk
```
    ./gradlew :serverShell:assemble
    or
    ./gradlew :serverShell:assembleDebug    //调试模式下用该方案，加快编译速度
```
3.运行copyPlugin任务
```
    "cd <项目根目录>" -> "./gradlew copyPlugin"
```
错误分析:
1.基于AS右侧的Gradle_Task -> ServerShell ->Tasks -> other -> copyPlugin提示错误信息
"Failed to create parent directory '/posDinnerClient' when creating directory '/posDinnerClient/src/debug/assets/plugin'"
分析：脚本中的"new File('./serverShell/shell.properties')"部分需要基于项目根目录

其他：
1.插件内容会copy至"<shell.properties下path参数>/posDinnerClient/src/<buildType>/assets/plugin/"下



# 业务中心插件使用流程(新版本)
## 插件deploy
### 使用说明
1.提交代码至git远程
注意事项：若newmydandroidserver与mydandroidcommon均有修改，务必提交到相同的远程分支
2.进入"http://jks.mwbyd.cn/jenkins/job/MYD_Plugin/build?delay=0sec"，输入需要构建插件包的分支以及buildType
3.进入"http://svn.mwbyd.cn/APK/MYD_Plugin/Repositories/BizCenterPlugin/"即查看到编译完成的插件包资源
注：插件包资源以业务中心项目分支名区分，zip格式插件包以"plugin_<git的commitid短号>_<buildType>.zip"方式命名

### 流程说明
1.clean
```
./gradlew :serveShell:clean
```
2.编译插件apk
```
    ./gradlew :serverShell:assemble
    or
    ./gradlew :serverShell:assembleDebug
```
3.生成zip格式的插件包资源
```
./gradlew :serverShell:deployPlugin
```
分析：该task会在serverShell/build/client_plugins下生成buildtype对应的插件宝资源
4.jenkins上job发布插件包zip资源至svn对应路径


## 客户端使用说明
1.<项目根目录>/build.gradle下添加
```
    dependencies {
        classpath 'de.undercouch:gradle-download-task:3.4.3'
        classpath 'org.apache.httpcomponents:httpclient:4.5.5'
    }
```
2.<module>/build.gradle下添加
```
apply plugin: 'de.undercouch.download'
```
3.在需要应用插件包的module下的build.gradle中添加以下配置，其中个性化定制块中需要根据开发分支修改对应的插件包引用
```
applicationVariants.all { variant ->
        variant.outputs.all {
            //-------------个性化定制部分(根据项目分支切换插件包):start--------------
            def pluginPathInDepot = null   //插件对应的仓库下子路径，zip格式，内部包含path.properties & 插件apk
            if (variant.buildType.name == ("release")) {
                pluginPathInDepot = "tmp/plugin_38e8c40_release.zip"
            } else if (variant.buildType.name == ("uat")) {
                pluginPathInDepot = "tmp/plugin_38e8c40_uat.zip"
            } else if (variant.buildType.name == ("debug")) {
                pluginPathInDepot = "tmp/plugin_38e8c40_debug.zip"
            }
            //---------------个性化定制：end---------------

            def buildName = variant.name.capitalize().toLowerCase()
            //插件下载
            def serverDepotPath = "http://svn.mwbyd.cn/APK/MYD_Plugin/"   //业务中心插件库仓库地址
            def downloadZipFileTask = tasks.create("downloadZipFile${buildName}", Download)
            downloadZipFileTask.src(serverDepotPath + pluginPathInDepot)
            downloadZipFileTask.username("<svn user name>")     //自行修改
            downloadZipFileTask.password("<svn password>")      //自行修改
            downloadZipFileTask.onlyIfModified(true)
            def pluginZipName = pluginPathInDepot.split("/")[-1]
            downloadZipFileTask.dest(new File(buildDir, pluginZipName))
            //插件解压
            def targettUnzipDir = new File(buildDir.getPath() + "/../src/${buildName}/assets/plugin")
            def unZipTask = tasks.create("applyPlugin${buildName}", Copy) {
                doFirst {
                    if (!targettUnzipDir.exists()) {
                        targettUnzipDir.mkdirs()
                    }
                }
            }
            unZipTask.from(zipTree(downloadZipFileTask.dest))
            unZipTask.into(targettUnzipDir)
            unZipTask.mustRunAfter(downloadZipFileTask)
            unZipTask.dependsOn(downloadZipFileTask)
        }
    }
```
4.应用插件
执行以下命令，即可在客户端module/src/<buildTypes>/assets/plugin下生成插件包资源
```
./gradlew :serverTestApp:applyPluginDebug
./gradlew :serverTestApp:applyPluginRelease
./gradlew :serverTestApp:applyPluginUat
```
